
import React from "react";
import { NavLink } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { cn } from "@/lib/utils";
import { 
  Home, 
  Calendar, 
  FileText, 
  MessageSquare, 
  User, 
  Users, 
  BarChart, 
  Settings,
  LogOut
} from "lucide-react";

const Sidebar: React.FC = () => {
  const { user, logout } = useAuth();

  if (!user) return null;

  const navItems = [
    {
      label: "Dashboard",
      icon: <Home size={20} />,
      path: "/dashboard",
      roles: ["admin", "doctor", "patient"],
    },
    {
      label: "Appointments",
      icon: <Calendar size={20} />,
      path: "/appointments",
      roles: ["admin", "doctor", "patient"],
    },
    {
      label: "Medical Records",
      icon: <FileText size={20} />,
      path: "/medical-records",
      roles: ["admin", "doctor", "patient"],
    },
    {
      label: "Messages",
      icon: <MessageSquare size={20} />,
      path: "/messages",
      roles: ["admin", "doctor", "patient"],
    },
    {
      label: "Profile",
      icon: <User size={20} />,
      path: "/profile",
      roles: ["admin", "doctor", "patient"],
    },
    {
      label: "Users",
      icon: <Users size={20} />,
      path: "/users",
      roles: ["admin"],
    },
    {
      label: "Analytics",
      icon: <BarChart size={20} />,
      path: "/analytics",
      roles: ["admin"],
    },
    {
      label: "Settings",
      icon: <Settings size={20} />,
      path: "/settings",
      roles: ["admin", "doctor", "patient"],
    },
  ];

  const filteredNavItems = navItems.filter(item => item.roles.includes(user.role));

  return (
    <aside className="bg-white border-r border-gray-200 w-64 hidden md:flex flex-col h-screen">
      <div className="flex items-center justify-center p-6 border-b border-gray-200">
        <h1 className="text-2xl font-bold">
          <span className="text-health-blue">E</span>-Health
        </h1>
      </div>
      <div className="flex-1 overflow-y-auto py-4">
        <nav className="px-4 space-y-1">
          {filteredNavItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) =>
                cn(
                  "flex items-center px-4 py-3 text-gray-600 rounded-lg",
                  "transition-all duration-200 ease-in-out",
                  isActive
                    ? "bg-health-blue-light text-health-blue font-medium"
                    : "hover:bg-gray-100"
                )
              }
            >
              <span className="mr-3">{item.icon}</span>
              <span>{item.label}</span>
            </NavLink>
          ))}
        </nav>
      </div>
      <div className="p-4 border-t border-gray-200">
        <button
          onClick={logout}
          className="flex items-center w-full px-4 py-3 text-gray-600 rounded-lg hover:bg-gray-100 transition-all"
        >
          <LogOut size={20} className="mr-3" />
          <span>Logout</span>
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;
