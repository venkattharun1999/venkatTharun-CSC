
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";

// Layout
import Layout from "@/components/Layout/Layout";

// Auth Pages
import Login from "@/pages/Auth/Login";
import Register from "@/pages/Auth/Register";
import ForgotPassword from "@/pages/Auth/ForgotPassword";

// Dashboard
import Dashboard from "@/pages/Dashboard/Dashboard";

// Appointments
import Appointments from "@/pages/Appointments/Appointments";
import AppointmentDetails from "@/pages/Appointments/AppointmentDetails";
import NewAppointment from "@/pages/Appointments/NewAppointment";

// Medical Records
import MedicalRecords from "@/pages/MedicalRecords/MedicalRecords";
import RecordDetails from "@/pages/MedicalRecords/RecordDetails";
import NewRecord from "@/pages/MedicalRecords/NewRecord";

// Messages
import Messages from "@/pages/Messages/Messages";
import Conversation from "@/pages/Messages/Conversation";

// Profile
import Profile from "@/pages/Profile/Profile";

// Admin Pages
import Users from "@/pages/Admin/Users";
import Analytics from "@/pages/Admin/Analytics";

// Settings
import Settings from "@/pages/Settings/Settings";

// Landing Page
import Landing from "@/pages/Landing/Landing";

// Error Pages
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            {/* Public Routes */}
            <Route path="/" element={<Landing />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/forgot-password" element={<ForgotPassword />} />

            {/* Protected Routes */}
            <Route path="/" element={<Layout />}>
              <Route path="/dashboard" element={<Dashboard />} />
              
              {/* Appointments Routes */}
              <Route path="/appointments" element={<Appointments />} />
              <Route path="/appointments/new" element={<NewAppointment />} />
              <Route path="/appointments/:id" element={<AppointmentDetails />} />
              
              {/* Medical Records Routes */}
              <Route path="/medical-records" element={<MedicalRecords />} />
              <Route path="/medical-records/new" element={<NewRecord />} />
              <Route path="/medical-records/:id" element={<RecordDetails />} />
              
              {/* Messages Routes */}
              <Route path="/messages" element={<Messages />} />
              <Route path="/messages/:id" element={<Conversation />} />
              
              {/* User Profile */}
              <Route path="/profile" element={<Profile />} />
              
              {/* Admin Routes */}
              <Route path="/users" element={<Users />} />
              <Route path="/analytics" element={<Analytics />} />
              
              {/* Settings */}
              <Route path="/settings" element={<Settings />} />
            </Route>

            {/* Catch-all Route */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
