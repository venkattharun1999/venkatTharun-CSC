
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { mockStats } from "@/data/mockData";
import { 
  Calendar, 
  ClipboardList, 
  MessageSquare,
  Pill,
  FileText,
  ArrowRight,
  CheckCircle,
  ChevronRight,
  AlertCircle
} from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { useNavigate } from "react-router-dom";
import { Progress } from "@/components/ui/progress";

const { patient: stats } = mockStats;

const PatientDashboard: React.FC = () => {
  const navigate = useNavigate();
  
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="health-dashboard-card col-span-1 lg:col-span-2">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg font-medium">Next Appointment</CardTitle>
          </CardHeader>
          <CardContent>
            {stats.upcomingAppointment ? (
              <div className="bg-gradient-to-r from-health-blue/10 to-health-green/10 rounded-xl p-6">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                  <div className="flex items-center mb-4 md:mb-0">
                    <div className="hidden md:block p-4 bg-white rounded-xl shadow-sm mr-6">
                      <Calendar className="h-8 w-8 text-health-blue" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold">{stats.upcomingAppointment.doctorName}</h3>
                      <p className="text-sm text-gray-600">{stats.upcomingAppointment.specialization}</p>
                      <div className="flex items-center mt-1">
                        <Calendar className="h-4 w-4 text-gray-500 mr-1" />
                        <span className="text-sm text-gray-600">
                          {stats.upcomingAppointment.date} at {stats.upcomingAppointment.time}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-2">
                    <Button variant="outline" onClick={() => navigate("/messages")}>
                      <MessageSquare size={18} className="mr-2" />
                      Message
                    </Button>
                    <Button onClick={() => navigate("/appointments")}>
                      <ClipboardList size={18} className="mr-2" />
                      View Details
                    </Button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-8">
                <Calendar className="h-12 w-12 mx-auto text-gray-300" />
                <h3 className="mt-2 text-lg font-medium">No Upcoming Appointments</h3>
                <p className="text-sm text-gray-500 mb-4">Schedule an appointment with your doctor</p>
                <Button onClick={() => navigate("/appointments/new")}>
                  Schedule Appointment
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="health-dashboard-card">
          <CardHeader className="pb-3 flex flex-row items-center justify-between">
            <CardTitle className="text-lg font-medium">Medication Reminders</CardTitle>
            <Button variant="ghost" size="sm" className="text-gray-400 hover:text-gray-900">
              <ArrowRight size={16} />
            </Button>
          </CardHeader>
          <CardContent>
            {stats.medicationReminders.length > 0 ? (
              <div className="space-y-4">
                {stats.medicationReminders.map((med, index) => (
                  <div key={index} className="flex items-center justify-between border-b border-gray-100 pb-4 last:border-0 last:pb-0">
                    <div className="flex items-center">
                      <div className={`p-2 rounded-full ${med.taken ? 'bg-health-green-light' : 'bg-health-blue-light'}`}>
                        <Pill size={18} className={med.taken ? 'text-health-green' : 'text-health-blue'} />
                      </div>
                      <div className="ml-3">
                        <h3 className="font-medium">{med.medication}</h3>
                        <p className="text-sm text-gray-500">{med.time}</p>
                      </div>
                    </div>
                    {med.taken ? (
                      <Badge variant="outline" className="bg-health-green-light text-health-green border-0">
                        <CheckCircle size={14} className="mr-1" />
                        Taken
                      </Badge>
                    ) : (
                      <Badge variant="outline" className="bg-health-red-light text-health-red border-0">
                        <AlertCircle size={14} className="mr-1" />
                        Due
                      </Badge>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-6">
                <Pill className="h-12 w-12 mx-auto text-gray-300" />
                <h3 className="mt-2 text-lg font-medium">No Medications</h3>
                <p className="text-sm text-gray-500">You have no medication reminders</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="health-dashboard-card">
          <CardHeader className="pb-3 flex flex-row items-center justify-between">
            <CardTitle className="text-lg font-medium">Recent Records</CardTitle>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => navigate("/medical-records")}
            >
              View All <ArrowRight size={16} className="ml-1" />
            </Button>
          </CardHeader>
          <CardContent>
            {stats.recentRecords.length > 0 ? (
              <div className="space-y-4">
                {stats.recentRecords.map((record, index) => (
                  <div key={index} className="group flex items-center justify-between p-4 rounded-lg border border-gray-100 hover:border-health-blue hover:bg-health-blue-light/10 transition-all cursor-pointer" onClick={() => navigate("/medical-records")}>
                    <div className="flex items-center">
                      <div className="p-2 rounded-full bg-white border border-gray-100">
                        <FileText size={16} className="text-health-blue" />
                      </div>
                      <div className="ml-3">
                        <h3 className="font-medium">{record.type}</h3>
                        <p className="text-sm text-gray-500">{record.date}</p>
                      </div>
                    </div>
                    <ChevronRight size={16} className="text-gray-400 group-hover:text-health-blue transition-colors" />
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-6">
                <FileText className="h-12 w-12 mx-auto text-gray-300" />
                <h3 className="mt-2 text-lg font-medium">No Records</h3>
                <p className="text-sm text-gray-500">You have no medical records yet</p>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="health-dashboard-card col-span-1 lg:col-span-2">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg font-medium">Health Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-6 grid-cols-1 sm:grid-cols-2">
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm font-medium">Blood Pressure</span>
                    <span className="text-sm text-gray-500">120/80 mmHg</span>
                  </div>
                  <Progress value={75} className="h-2" />
                  <p className="text-xs text-gray-500 mt-1">Last checked: 2 weeks ago</p>
                </div>
                
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm font-medium">Glucose Level</span>
                    <span className="text-sm text-gray-500">95 mg/dL</span>
                  </div>
                  <Progress value={85} className="h-2" />
                  <p className="text-xs text-gray-500 mt-1">Last checked: 1 month ago</p>
                </div>
                
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm font-medium">Heart Rate</span>
                    <span className="text-sm text-gray-500">72 bpm</span>
                  </div>
                  <Progress value={80} className="h-2" />
                  <p className="text-xs text-gray-500 mt-1">Last checked: 2 weeks ago</p>
                </div>
              </div>
              
              <div className="bg-gray-50 rounded-xl p-6">
                <h3 className="font-semibold text-gray-800 mb-4">Recent Diagnosis</h3>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-medium text-health-blue">Hypertension (Stage 1)</h4>
                    <p className="text-sm text-gray-600 mt-1">
                      Dr. Sarah Johnson - Cardiology
                    </p>
                    <p className="text-xs text-gray-500 mt-1">Diagnosed on: March 10, 2025</p>
                  </div>
                  <div className="pt-4 border-t border-gray-200">
                    <h4 className="font-medium">Treatment Plan</h4>
                    <ul className="text-sm text-gray-600 mt-2 space-y-2">
                      <li className="flex items-start">
                        <CheckCircle size={14} className="text-health-green mr-2 mt-1" />
                        <span>Lisinopril 10mg once daily</span>
                      </li>
                      <li className="flex items-start">
                        <CheckCircle size={14} className="text-health-green mr-2 mt-1" />
                        <span>Low-sodium diet</span>
                      </li>
                      <li className="flex items-start">
                        <CheckCircle size={14} className="text-health-green mr-2 mt-1" />
                        <span>Regular exercise - 30 minutes daily</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default PatientDashboard;
