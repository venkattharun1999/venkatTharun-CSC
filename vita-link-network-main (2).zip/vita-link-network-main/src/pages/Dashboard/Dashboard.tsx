
import React from "react";
import { useAuth } from "@/contexts/AuthContext";
import AdminDashboard from "./AdminDashboard";
import DoctorDashboard from "./DoctorDashboard";
import PatientDashboard from "./PatientDashboard";

const Dashboard: React.FC = () => {
  const { user } = useAuth();

  if (!user) {
    return null;
  }

  return (
    <div className="animate-fade-in">
      <h1 className="text-2xl font-bold mb-6">Dashboard</h1>
      
      {user.role === "admin" && <AdminDashboard />}
      {user.role === "doctor" && <DoctorDashboard />}
      {user.role === "patient" && <PatientDashboard />}
    </div>
  );
};

export default Dashboard;
