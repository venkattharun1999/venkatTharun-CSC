
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { mockStats } from "@/data/mockData";
import { 
  Users, 
  UserCheck, 
  Calendar, 
  CheckCircle,
  Clock,
  XCircle
} from "lucide-react";
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts";

const { admin: stats } = mockStats;

const AdminDashboard: React.FC = () => {
  const pieData = [
    { name: "Confirmed", value: stats.appointments.confirmed, color: "#4FCB8D" },
    { name: "Pending", value: stats.appointments.pending, color: "#4A9FEA" },
    { name: "Cancelled", value: stats.appointments.cancelled, color: "#FF6B6B" }
  ];

  const userGrowthData = [
    { name: "Jan", users: stats.userGrowth[0] },
    { name: "Feb", users: stats.userGrowth[1] },
    { name: "Mar", users: stats.userGrowth[2] },
    { name: "Apr", users: stats.userGrowth[3] },
    { name: "May", users: stats.userGrowth[4] },
    { name: "Jun", users: stats.userGrowth[5] },
    { name: "Jul", users: stats.userGrowth[6] },
  ];

  const appointmentsData = [
    { name: "Mon", appointments: stats.appointmentsPerDay[0] },
    { name: "Tue", appointments: stats.appointmentsPerDay[1] },
    { name: "Wed", appointments: stats.appointmentsPerDay[2] },
    { name: "Thu", appointments: stats.appointmentsPerDay[3] },
    { name: "Fri", appointments: stats.appointmentsPerDay[4] },
    { name: "Sat", appointments: stats.appointmentsPerDay[5] },
    { name: "Sun", appointments: stats.appointmentsPerDay[6] },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="health-dashboard-card">
          <CardContent className="pt-6">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-health-blue-light text-health-blue">
                <Users size={24} />
              </div>
              <div className="ml-4">
                <p className="text-sm text-gray-500">Total Users</p>
                <h2 className="text-2xl font-bold">{stats.totalUsers}</h2>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="health-dashboard-card">
          <CardContent className="pt-6">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-health-green-light text-health-green-dark">
                <UserCheck size={24} />
              </div>
              <div className="ml-4">
                <p className="text-sm text-gray-500">Total Doctors</p>
                <h2 className="text-2xl font-bold">{stats.totalDoctors}</h2>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="health-dashboard-card">
          <CardContent className="pt-6">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-health-blue-light text-health-blue">
                <Users size={24} />
              </div>
              <div className="ml-4">
                <p className="text-sm text-gray-500">Total Patients</p>
                <h2 className="text-2xl font-bold">{stats.totalPatients}</h2>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="health-dashboard-card">
          <CardContent className="pt-6">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-health-green-light text-health-green-dark">
                <Calendar size={24} />
              </div>
              <div className="ml-4">
                <p className="text-sm text-gray-500">Total Appointments</p>
                <h2 className="text-2xl font-bold">{stats.appointments.total}</h2>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="health-dashboard-card col-span-1 lg:col-span-2">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg font-medium">User Growth</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={userGrowthData}
                  margin={{
                    top: 5,
                    right: 30,
                    left: 20,
                    bottom: 5,
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Line
                    type="monotone"
                    dataKey="users"
                    stroke="#4A9FEA"
                    strokeWidth={2}
                    dot={{ r: 4 }}
                    activeDot={{ r: 8 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card className="health-dashboard-card">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg font-medium">Appointment Status</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={70}
                    outerRadius={90}
                    paddingAngle={5}
                    dataKey="value"
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex justify-center space-x-6 mt-2">
              <div className="flex items-center">
                <div className="w-3 h-3 rounded-full bg-health-green-dark mr-2"></div>
                <span className="text-sm text-gray-600">Confirmed</span>
              </div>
              <div className="flex items-center">
                <div className="w-3 h-3 rounded-full bg-health-blue mr-2"></div>
                <span className="text-sm text-gray-600">Pending</span>
              </div>
              <div className="flex items-center">
                <div className="w-3 h-3 rounded-full bg-health-red mr-2"></div>
                <span className="text-sm text-gray-600">Cancelled</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="health-dashboard-card col-span-1">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg font-medium">Recent Activities</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {stats.recentActivities.map((activity) => (
                <div key={activity.id} className="flex items-start">
                  <div className="w-2 h-2 mt-2 rounded-full bg-health-blue mr-3"></div>
                  <div>
                    <p className="text-sm font-medium">{activity.user}</p>
                    <p className="text-sm text-gray-500">{activity.activity}</p>
                    <p className="text-xs text-gray-400 mt-1">{activity.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="health-dashboard-card col-span-1 lg:col-span-2">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg font-medium">Appointments per Day</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={appointmentsData}
                  margin={{
                    top: 5,
                    right: 30,
                    left: 20,
                    bottom: 5,
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="appointments" fill="#4A9FEA" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default AdminDashboard;
