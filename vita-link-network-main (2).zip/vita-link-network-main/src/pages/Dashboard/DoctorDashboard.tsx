
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { mockStats, mockAppointments } from "@/data/mockData";
import { 
  Users, 
  Calendar, 
  MessageSquare,
  Clock,
  CheckCircle,
  XCircle,
  ArrowRight
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

const { doctor: stats } = mockStats;

const DoctorDashboard: React.FC = () => {
  const navigate = useNavigate();
  
  // Get today's and tomorrow's appointments
  const todaysDate = new Date().toISOString().split('T')[0];
  const tomorrowsDate = new Date(new Date().setDate(new Date().getDate() + 1)).toISOString().split('T')[0];
  
  const todaysAppointments = mockAppointments.filter(
    app => app.date === todaysDate && app.status !== "cancelled"
  );
  
  const upcomingAppointments = mockAppointments.filter(
    app => app.status === "confirmed" || app.status === "pending"
  ).slice(0, 5);
  
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="health-dashboard-card">
          <CardContent className="pt-6">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-health-blue-light text-health-blue">
                <Users size={24} />
              </div>
              <div className="ml-4">
                <p className="text-sm text-gray-500">Total Patients</p>
                <h2 className="text-2xl font-bold">{stats.totalPatients}</h2>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="health-dashboard-card">
          <CardContent className="pt-6">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-health-green-light text-health-green-dark">
                <Calendar size={24} />
              </div>
              <div className="ml-4">
                <p className="text-sm text-gray-500">Today's Appointments</p>
                <h2 className="text-2xl font-bold">{stats.appointmentsToday}</h2>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="health-dashboard-card">
          <CardContent className="pt-6">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-health-blue-light text-health-blue">
                <Clock size={24} />
              </div>
              <div className="ml-4">
                <p className="text-sm text-gray-500">Tomorrow's Appointments</p>
                <h2 className="text-2xl font-bold">{stats.appointmentsTomorrow}</h2>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="health-dashboard-card">
          <CardContent className="pt-6">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-health-red-light text-health-red-dark">
                <MessageSquare size={24} />
              </div>
              <div className="ml-4">
                <p className="text-sm text-gray-500">Unread Messages</p>
                <h2 className="text-2xl font-bold">{stats.unreadMessages}</h2>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="health-dashboard-card">
          <CardHeader className="pb-3 flex flex-row items-center justify-between">
            <CardTitle className="text-lg font-medium">Today's Schedule</CardTitle>
            <Button variant="outline" size="sm" onClick={() => navigate("/appointments")}>
              View All <ArrowRight size={16} className="ml-1" />
            </Button>
          </CardHeader>
          <CardContent>
            {todaysAppointments.length > 0 ? (
              <div className="space-y-4">
                {todaysAppointments.map((appointment) => (
                  <div key={appointment.id} className="flex items-start border-b border-gray-100 pb-4 last:border-0 last:pb-0">
                    <Avatar className="h-10 w-10">
                      <AvatarImage src={appointment.patientAvatar} alt={appointment.patientName} />
                      <AvatarFallback>
                        {appointment.patientName.split(" ").map(n => n[0]).join("")}
                      </AvatarFallback>
                    </Avatar>
                    <div className="ml-4 flex-1">
                      <div className="flex items-center justify-between">
                        <h3 className="font-medium">{appointment.patientName}</h3>
                        <Badge variant={appointment.status === "confirmed" ? "default" : "secondary"}>
                          {appointment.status === "confirmed" ? (
                            <CheckCircle size={14} className="mr-1" />
                          ) : (
                            <Clock size={14} className="mr-1" />
                          )}
                          {appointment.status.charAt(0).toUpperCase() + appointment.status.slice(1)}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-500 mt-1">{appointment.time} - {appointment.symptoms}</p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-6">
                <Calendar className="h-12 w-12 mx-auto text-gray-300" />
                <h3 className="mt-2 text-lg font-medium">No Appointments Today</h3>
                <p className="text-sm text-gray-500">Enjoy your free day!</p>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="health-dashboard-card">
          <CardHeader className="pb-3 flex flex-row items-center justify-between">
            <CardTitle className="text-lg font-medium">Upcoming Appointments</CardTitle>
            <Button variant="outline" size="sm" onClick={() => navigate("/appointments")}>
              View All <ArrowRight size={16} className="ml-1" />
            </Button>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Patient</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Time</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {upcomingAppointments.map((appointment) => (
                  <TableRow key={appointment.id}>
                    <TableCell className="font-medium">
                      <div className="flex items-center">
                        <Avatar className="h-8 w-8 mr-2">
                          <AvatarImage src={appointment.patientAvatar} alt={appointment.patientName} />
                          <AvatarFallback>
                            {appointment.patientName.split(" ").map(n => n[0]).join("")}
                          </AvatarFallback>
                        </Avatar>
                        {appointment.patientName}
                      </div>
                    </TableCell>
                    <TableCell>{appointment.date}</TableCell>
                    <TableCell>{appointment.time}</TableCell>
                    <TableCell>
                      <Badge variant={appointment.status === "confirmed" ? "default" : "secondary"}>
                        {appointment.status.charAt(0).toUpperCase() + appointment.status.slice(1)}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>

      <Card className="health-dashboard-card">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg font-medium">Recent Patients</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {stats.recentPatients.map((patient) => (
              <div key={patient.id} className="health-card">
                <div className="flex justify-between items-start">
                  <div className="flex items-center space-x-3">
                    <Avatar className="h-10 w-10">
                      <AvatarImage src={`https://i.pravatar.cc/150?img=${Math.floor(Math.random() * 70)}`} />
                      <AvatarFallback>
                        {patient.name.split(" ").map(n => n[0]).join("")}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="font-medium">{patient.name}</h3>
                      <p className="text-sm text-gray-500">{patient.time}</p>
                    </div>
                  </div>
                  <Badge 
                    variant={
                      patient.status === "Confirmed" ? "default" : 
                      patient.status === "Cancelled" ? "destructive" : "secondary"
                    }
                  >
                    {patient.status}
                  </Badge>
                </div>
                <div className="mt-4 flex justify-center space-x-2">
                  <Button variant="outline" size="sm" onClick={() => navigate("/medical-records")}>
                    View Records
                  </Button>
                  <Button size="sm" onClick={() => navigate("/messages")}>
                    Message
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default DoctorDashboard;
