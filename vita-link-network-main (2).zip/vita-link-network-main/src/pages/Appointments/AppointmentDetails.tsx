
import React, { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { mockAppointments } from "@/data/mockData";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { AppointmentStatus } from "@/types/appointment";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardFooter 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  ArrowLeft, 
  Calendar, 
  Clock, 
  MapPin, 
  FileText, 
  User, 
  MessageSquare, 
  AlertCircle,
  Check,
  X
} from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";

const AppointmentDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toast } = useToast();
  const [reason, setReason] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [actionType, setActionType] = useState<"confirm" | "cancel" | "complete">("confirm");
  
  if (!user) return null;
  
  const appointment = mockAppointments.find(app => app.id === id);
  
  if (!appointment) {
    return (
      <div className="flex flex-col items-center justify-center py-12">
        <AlertCircle className="h-12 w-12 text-health-red mb-4" />
        <h1 className="text-2xl font-bold mb-2">Appointment Not Found</h1>
        <p className="text-gray-600 mb-4">The appointment you're looking for doesn't exist or has been removed.</p>
        <Button onClick={() => navigate("/appointments")}>
          Go Back to Appointments
        </Button>
      </div>
    );
  }
  
  // Check if user has permission to view this appointment
  const hasPermission = 
    user.role === "admin" || 
    (user.role === "doctor" && appointment.doctorId === user.id) || 
    (user.role === "patient" && appointment.patientId === user.id);
    
  if (!hasPermission) {
    return (
      <div className="flex flex-col items-center justify-center py-12">
        <AlertCircle className="h-12 w-12 text-health-red mb-4" />
        <h1 className="text-2xl font-bold mb-2">Access Denied</h1>
        <p className="text-gray-600 mb-4">You don't have permission to view this appointment.</p>
        <Button onClick={() => navigate("/appointments")}>
          Go Back to Appointments
        </Button>
      </div>
    );
  }
  
  const handleActionClick = (type: "confirm" | "cancel" | "complete") => {
    setActionType(type);
    setDialogOpen(true);
  };
  
  const handleAction = () => {
    // In a real app, we would update the appointment status in the backend
    
    let message = "";
    switch (actionType) {
      case "confirm":
        message = "Appointment confirmed successfully";
        break;
      case "cancel":
        message = "Appointment cancelled successfully";
        break;
      case "complete":
        message = "Appointment marked as completed";
        break;
    }
    
    toast({
      title: "Success",
      description: message,
    });
    
    setDialogOpen(false);
    // Navigate back to refresh the page
    navigate("/appointments");
  };
  
  const getStatusBadge = (status: AppointmentStatus) => {
    switch (status) {
      case "confirmed":
        return <Badge className="bg-health-green-light text-health-green border-0">Confirmed</Badge>;
      case "pending":
        return <Badge className="bg-health-blue-light text-health-blue border-0">Pending</Badge>;
      case "cancelled":
        return <Badge className="bg-health-red-light text-health-red-dark border-0">Cancelled</Badge>;
      case "completed":
        return <Badge className="bg-gray-100 text-gray-600 border-0">Completed</Badge>;
    }
  };
  
  return (
    <div className="animate-fade-in space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => navigate("/appointments")}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-2xl font-bold">Appointment Details</h1>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2 space-y-6">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg font-medium">Appointment Information</CardTitle>
                {getStatusBadge(appointment.status)}
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-center">
                  <Calendar className="h-5 w-5 text-health-blue mr-2" />
                  <div>
                    <p className="text-sm text-gray-500">Date</p>
                    <p className="font-medium">{appointment.date}</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <Clock className="h-5 w-5 text-health-blue mr-2" />
                  <div>
                    <p className="text-sm text-gray-500">Time</p>
                    <p className="font-medium">{appointment.time} ({appointment.duration} min)</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <MapPin className="h-5 w-5 text-health-blue mr-2" />
                  <div>
                    <p className="text-sm text-gray-500">Location</p>
                    <p className="font-medium">E-Health Medical Center, Room 305</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <FileText className="h-5 w-5 text-health-blue mr-2" />
                  <div>
                    <p className="text-sm text-gray-500">Specialization</p>
                    <p className="font-medium">{appointment.specialization}</p>
                  </div>
                </div>
              </div>
              
              <div className="pt-4 border-t border-gray-100">
                <h3 className="font-medium mb-2">Symptoms / Reason for Visit</h3>
                <p className="text-gray-700">{appointment.symptoms || "No symptoms provided."}</p>
              </div>
              
              {appointment.notes && (
                <div className="pt-4 border-t border-gray-100">
                  <h3 className="font-medium mb-2">Doctor's Notes</h3>
                  <p className="text-gray-700">{appointment.notes}</p>
                </div>
              )}
            </CardContent>
            {appointment.status !== "completed" && appointment.status !== "cancelled" && (
              <CardFooter className="border-t border-gray-100 pt-4 gap-2 flex flex-wrap">
                {user.role === "doctor" && appointment.status === "pending" && (
                  <Button 
                    variant="default" 
                    className="bg-health-green hover:bg-health-green-dark"
                    onClick={() => handleActionClick("confirm")}
                  >
                    <Check className="h-4 w-4 mr-2" />
                    Confirm Appointment
                  </Button>
                )}
                
                {user.role === "doctor" && appointment.status === "confirmed" && (
                  <Button 
                    variant="default"
                    onClick={() => handleActionClick("complete")}
                  >
                    <Check className="h-4 w-4 mr-2" />
                    Mark as Completed
                  </Button>
                )}
                
                {(user.role === "patient" || user.role === "doctor" || user.role === "admin") && 
                  (appointment.status === "pending" || appointment.status === "confirmed") && (
                  <Button 
                    variant="destructive"
                    onClick={() => handleActionClick("cancel")}
                  >
                    <X className="h-4 w-4 mr-2" />
                    Cancel Appointment
                  </Button>
                )}
              </CardFooter>
            )}
          </Card>
        </div>
        
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg font-medium">
              {user.role === "patient" ? "Doctor Information" : "Patient Information"}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center">
              <Avatar className="h-16 w-16">
                <AvatarImage src={user.role === "patient" ? appointment.doctorAvatar : appointment.patientAvatar} />
                <AvatarFallback>
                  {user.role === "patient" 
                    ? appointment.doctorName.split(" ").map(n => n[0]).join("")
                    : appointment.patientName.split(" ").map(n => n[0]).join("")}
                </AvatarFallback>
              </Avatar>
              <div className="ml-4">
                <h3 className="font-medium">
                  {user.role === "patient" ? appointment.doctorName : appointment.patientName}
                </h3>
                <p className="text-sm text-gray-500">
                  {user.role === "patient" ? appointment.specialization : "Patient ID: " + appointment.patientId.substring(0, 8)}
                </p>
              </div>
            </div>
            
            {user.role === "patient" && (
              <div className="pt-4 border-t border-gray-100">
                <h3 className="font-medium mb-2">About Doctor</h3>
                <p className="text-gray-700 text-sm">
                  Dr. {appointment.doctorName.split(" ")[1]} is a specialist in {appointment.specialization} with over 10 years of experience. They are dedicated to providing the highest quality care to all patients.
                </p>
              </div>
            )}
            
            <div className="flex flex-col gap-2 pt-4">
              <Button variant="outline" className="w-full" onClick={() => navigate("/messages")}>
                <MessageSquare className="h-4 w-4 mr-2" />
                Send Message
              </Button>
              
              {user.role === "doctor" && (
                <Button variant="outline" className="w-full" onClick={() => navigate("/medical-records/new")}>
                  <FileText className="h-4 w-4 mr-2" />
                  Create Medical Record
                </Button>
              )}
              
              {user.role === "doctor" && (
                <Button variant="outline" className="w-full" onClick={() => navigate("/medical-records")}>
                  <User className="h-4 w-4 mr-2" />
                  View Patient History
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
      
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {actionType === "confirm" ? "Confirm Appointment" : 
               actionType === "cancel" ? "Cancel Appointment" : "Complete Appointment"}
            </DialogTitle>
            <DialogDescription>
              {actionType === "confirm" 
                ? "Are you sure you want to confirm this appointment?" 
                : actionType === "cancel"
                ? "Are you sure you want to cancel this appointment? This action cannot be undone."
                : "Are you sure you want to mark this appointment as completed?"}
            </DialogDescription>
          </DialogHeader>
          
          {actionType === "cancel" && (
            <div className="space-y-2">
              <Label htmlFor="reason">Reason for cancellation</Label>
              <Textarea 
                id="reason" 
                placeholder="Please provide a reason for cancellation..." 
                value={reason}
                onChange={(e) => setReason(e.target.value)}
              />
            </div>
          )}
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button 
              variant={actionType === "cancel" ? "destructive" : "default"}
              onClick={handleAction}
            >
              {actionType === "confirm" ? "Confirm" : 
               actionType === "cancel" ? "Cancel Appointment" : "Mark as Completed"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AppointmentDetails;
