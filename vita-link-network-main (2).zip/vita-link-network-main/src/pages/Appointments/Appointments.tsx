
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { Appointment } from "@/types/appointment";
import { mockAppointments } from "@/data/mockData";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { 
  Calendar,
  Clock,
  CheckCircle,
  XCircle,
  Plus,
  Filter
} from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import AppointmentItem from "./components/AppointmentItem";
import AppointmentsFilter from "./components/AppointmentsFilter";

const Appointments: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [filter, setFilter] = useState<string>("all");
  const [showFilters, setShowFilters] = useState(false);
  
  if (!user) return null;
  
  // Filter appointments based on user role and selected filter
  const filteredAppointments = mockAppointments.filter(appointment => {
    // First filter by user role
    const roleFilter = 
      (user.role === "doctor" && appointment.doctorId === user.id) ||
      (user.role === "patient" && appointment.patientId === user.id) ||
      (user.role === "admin");
      
    // Then filter by status if applicable
    const statusFilter = 
      filter === "all" ? true :
      filter === "upcoming" ? (appointment.status === "confirmed" || appointment.status === "pending") :
      filter === "pending" ? appointment.status === "pending" :
      filter === "confirmed" ? appointment.status === "confirmed" :
      filter === "completed" ? appointment.status === "completed" :
      filter === "cancelled" ? appointment.status === "cancelled" :
      true;
      
    return roleFilter && statusFilter;
  });
  
  const getStatusCount = (status: string) => {
    return mockAppointments.filter(
      appointment => 
        ((user.role === "doctor" && appointment.doctorId === user.id) ||
        (user.role === "patient" && appointment.patientId === user.id) ||
        (user.role === "admin")) &&
        (status === "all" ? true : 
        status === "upcoming" ? (appointment.status === "confirmed" || appointment.status === "pending") :
        appointment.status === status)
    ).length;
  };

  return (
    <div className="animate-fade-in space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <h1 className="text-2xl font-bold">Appointments</h1>
        
        <div className="flex items-center gap-2">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => setShowFilters(!showFilters)}
          >
            <Filter size={16} className="mr-2" />
            Filters
          </Button>
          
          {(user.role === "patient" || user.role === "admin") && (
            <Button 
              size="sm" 
              onClick={() => navigate("/appointments/new")}
            >
              <Plus size={16} className="mr-2" />
              New Appointment
            </Button>
          )}
        </div>
      </div>
      
      {showFilters && <AppointmentsFilter setFilter={setFilter} />}
      
      <Tabs defaultValue="all" className="w-full" onValueChange={setFilter}>
        <TabsList className="grid grid-cols-2 md:grid-cols-5 mb-4">
          <TabsTrigger value="all">
            All ({getStatusCount("all")})
          </TabsTrigger>
          <TabsTrigger value="upcoming">
            Upcoming ({getStatusCount("upcoming")})
          </TabsTrigger>
          <TabsTrigger value="pending">
            Pending ({getStatusCount("pending")})
          </TabsTrigger>
          <TabsTrigger value="completed">
            Completed ({getStatusCount("completed")})
          </TabsTrigger>
          <TabsTrigger value="cancelled">
            Cancelled ({getStatusCount("cancelled")})
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="all" className="mt-0">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg font-medium">All Appointments</CardTitle>
            </CardHeader>
            <CardContent>
              {filteredAppointments.length > 0 ? (
                <div className="space-y-4">
                  {filteredAppointments.map(appointment => (
                    <AppointmentItem 
                      key={appointment.id}
                      appointment={appointment}
                      userRole={user.role}
                    />
                  ))}
                </div>
              ) : (
                <div className="text-center py-10">
                  <Calendar className="h-12 w-12 mx-auto text-gray-300" />
                  <h3 className="mt-2 text-lg font-medium">No Appointments Found</h3>
                  <p className="text-sm text-gray-500 mt-1 mb-4">
                    {filter === "all" 
                      ? "You don't have any appointments yet." 
                      : `You don't have any ${filter} appointments.`}
                  </p>
                  {user.role === "patient" && (
                    <Button onClick={() => navigate("/appointments/new")}>
                      Schedule an Appointment
                    </Button>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="upcoming" className="mt-0">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg font-medium">Upcoming Appointments</CardTitle>
            </CardHeader>
            <CardContent>
              {filteredAppointments.length > 0 ? (
                <div className="space-y-4">
                  {filteredAppointments.map(appointment => (
                    <AppointmentItem 
                      key={appointment.id}
                      appointment={appointment}
                      userRole={user.role}
                    />
                  ))}
                </div>
              ) : (
                <div className="text-center py-10">
                  <Calendar className="h-12 w-12 mx-auto text-gray-300" />
                  <h3 className="mt-2 text-lg font-medium">No Upcoming Appointments</h3>
                  <p className="text-sm text-gray-500 mt-1 mb-4">You don't have any upcoming appointments.</p>
                  {user.role === "patient" && (
                    <Button onClick={() => navigate("/appointments/new")}>
                      Schedule an Appointment
                    </Button>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="pending" className="mt-0">
          {/* Similar structure to above */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg font-medium">Pending Appointments</CardTitle>
            </CardHeader>
            <CardContent>
              {filteredAppointments.length > 0 ? (
                <div className="space-y-4">
                  {filteredAppointments.map(appointment => (
                    <AppointmentItem 
                      key={appointment.id}
                      appointment={appointment}
                      userRole={user.role}
                    />
                  ))}
                </div>
              ) : (
                <div className="text-center py-10">
                  <Clock className="h-12 w-12 mx-auto text-gray-300" />
                  <h3 className="mt-2 text-lg font-medium">No Pending Appointments</h3>
                  <p className="text-sm text-gray-500 mt-1 mb-4">You don't have any pending appointments.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="completed" className="mt-0">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg font-medium">Completed Appointments</CardTitle>
            </CardHeader>
            <CardContent>
              {filteredAppointments.length > 0 ? (
                <div className="space-y-4">
                  {filteredAppointments.map(appointment => (
                    <AppointmentItem 
                      key={appointment.id}
                      appointment={appointment}
                      userRole={user.role}
                    />
                  ))}
                </div>
              ) : (
                <div className="text-center py-10">
                  <CheckCircle className="h-12 w-12 mx-auto text-gray-300" />
                  <h3 className="mt-2 text-lg font-medium">No Completed Appointments</h3>
                  <p className="text-sm text-gray-500 mt-1 mb-4">You don't have any completed appointments yet.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="cancelled" className="mt-0">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg font-medium">Cancelled Appointments</CardTitle>
            </CardHeader>
            <CardContent>
              {filteredAppointments.length > 0 ? (
                <div className="space-y-4">
                  {filteredAppointments.map(appointment => (
                    <AppointmentItem 
                      key={appointment.id}
                      appointment={appointment}
                      userRole={user.role}
                    />
                  ))}
                </div>
              ) : (
                <div className="text-center py-10">
                  <XCircle className="h-12 w-12 mx-auto text-gray-300" />
                  <h3 className="mt-2 text-lg font-medium">No Cancelled Appointments</h3>
                  <p className="text-sm text-gray-500 mt-1 mb-4">You don't have any cancelled appointments.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Appointments;
