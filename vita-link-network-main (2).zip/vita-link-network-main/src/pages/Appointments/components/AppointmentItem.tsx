
import React from "react";
import { useNavigate } from "react-router-dom";
import { Appointment } from "@/types/appointment";
import { UserRole } from "@/types/auth";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, Clock, ChevronRight } from "lucide-react";

interface AppointmentItemProps {
  appointment: Appointment;
  userRole: UserRole;
}

const AppointmentItem: React.FC<AppointmentItemProps> = ({ appointment, userRole }) => {
  const navigate = useNavigate();
  
  const getStatusColor = (status: string) => {
    switch (status) {
      case "confirmed":
        return "bg-health-green-light text-health-green border-0";
      case "pending":
        return "bg-health-blue-light text-health-blue border-0";
      case "cancelled":
        return "bg-health-red-light text-health-red-dark border-0";
      case "completed":
        return "bg-gray-100 text-gray-600 border-0";
      default:
        return "";
    }
  };
  
  return (
    <div 
      className="flex flex-col md:flex-row md:items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-all cursor-pointer"
      onClick={() => navigate(`/appointments/${appointment.id}`)}
    >
      <div className="flex items-center mb-3 md:mb-0">
        <Avatar className="h-12 w-12">
          <AvatarImage src={userRole === "patient" ? appointment.doctorAvatar : appointment.patientAvatar} />
          <AvatarFallback>
            {userRole === "patient" 
              ? appointment.doctorName.split(" ").map(n => n[0]).join("")
              : appointment.patientName.split(" ").map(n => n[0]).join("")}
          </AvatarFallback>
        </Avatar>
        <div className="ml-4">
          <h3 className="font-medium">
            {userRole === "patient" ? appointment.doctorName : appointment.patientName}
          </h3>
          <p className="text-sm text-gray-500">{appointment.specialization}</p>
          <div className="flex items-center mt-1 space-x-4">
            <div className="flex items-center text-xs text-gray-500">
              <Calendar size={12} className="mr-1" />
              {appointment.date}
            </div>
            <div className="flex items-center text-xs text-gray-500">
              <Clock size={12} className="mr-1" />
              {appointment.time} ({appointment.duration} min)
            </div>
          </div>
        </div>
      </div>
      <div className="flex items-center justify-between md:justify-end w-full md:w-auto space-x-2">
        <Badge variant="outline" className={getStatusColor(appointment.status)}>
          {appointment.status.charAt(0).toUpperCase() + appointment.status.slice(1)}
        </Badge>
        <Button variant="ghost" size="icon">
          <ChevronRight size={16} />
        </Button>
      </div>
    </div>
  );
};

export default AppointmentItem;
