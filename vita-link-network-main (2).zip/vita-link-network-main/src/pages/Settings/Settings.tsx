
import React, { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardFooter 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Bell, 
  Shield, 
  Moon, 
  Sun, 
  Smartphone, 
  Mail, 
  Globe,
  Lock,
  UserCog,
  Languages
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const Settings: React.FC = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  
  const [activeTab, setActiveTab] = useState("notifications");
  
  // Form states
  const [notificationSettings, setNotificationSettings] = useState({
    emailNotifications: true,
    smsNotifications: false,
    appointmentReminders: true,
    appointmentUpdates: true,
    medicalRecordsUpdates: true,
    marketingEmails: false
  });
  
  const [appearanceSettings, setAppearanceSettings] = useState({
    theme: "light",
    fontSize: "medium",
    language: "english"
  });
  
  const [privacySettings, setPrivacySettings] = useState({
    profileVisibility: "all",
    dataSharing: true,
    analytics: true
  });
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  if (!user) return null;
  
  const handleSwitchChange = (field: string) => {
    setNotificationSettings(prev => ({
      ...prev,
      [field]: !prev[field as keyof typeof notificationSettings]
    }));
  };
  
  const handleSelectChange = (section: string, field: string, value: string) => {
    if (section === "appearance") {
      setAppearanceSettings(prev => ({
        ...prev,
        [field]: value
      }));
    } else if (section === "privacy") {
      setPrivacySettings(prev => ({
        ...prev,
        [field]: value
      }));
    }
  };
  
  const handleSubmit = (section: string) => {
    setIsSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      toast({
        title: "Settings Updated",
        description: `Your ${section} settings have been updated successfully.`,
      });
      setIsSubmitting(false);
    }, 1000);
  };
  
  return (
    <div className="animate-fade-in space-y-6">
      <h1 className="text-2xl font-bold">Settings</h1>
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid grid-cols-1 md:grid-cols-3 mb-6">
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
          <TabsTrigger value="appearance">Appearance</TabsTrigger>
          <TabsTrigger value="privacy">Privacy & Security</TabsTrigger>
        </TabsList>
        
        <TabsContent value="notifications">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg font-medium">Notification Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <h3 className="text-sm font-medium">Communication Channels</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <Mail className="w-5 h-5 text-gray-500" />
                      <div>
                        <Label htmlFor="emailNotifications" className="text-base">Email Notifications</Label>
                        <p className="text-sm text-gray-500">Receive notifications via email</p>
                      </div>
                    </div>
                    <Switch
                      id="emailNotifications"
                      checked={notificationSettings.emailNotifications}
                      onCheckedChange={() => handleSwitchChange("emailNotifications")}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <Smartphone className="w-5 h-5 text-gray-500" />
                      <div>
                        <Label htmlFor="smsNotifications" className="text-base">SMS Notifications</Label>
                        <p className="text-sm text-gray-500">Receive notifications via text message</p>
                      </div>
                    </div>
                    <Switch
                      id="smsNotifications"
                      checked={notificationSettings.smsNotifications}
                      onCheckedChange={() => handleSwitchChange("smsNotifications")}
                    />
                  </div>
                </div>
              </div>
              
              <div className="pt-4 border-t border-gray-100 space-y-4">
                <h3 className="text-sm font-medium">Notification Types</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="appointmentReminders" className="text-base">Appointment Reminders</Label>
                      <p className="text-sm text-gray-500">Get reminders about upcoming appointments</p>
                    </div>
                    <Switch
                      id="appointmentReminders"
                      checked={notificationSettings.appointmentReminders}
                      onCheckedChange={() => handleSwitchChange("appointmentReminders")}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="appointmentUpdates" className="text-base">Appointment Updates</Label>
                      <p className="text-sm text-gray-500">Get notified about appointment changes or cancellations</p>
                    </div>
                    <Switch
                      id="appointmentUpdates"
                      checked={notificationSettings.appointmentUpdates}
                      onCheckedChange={() => handleSwitchChange("appointmentUpdates")}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="medicalRecordsUpdates" className="text-base">Medical Records Updates</Label>
                      <p className="text-sm text-gray-500">Get notified when your medical records are updated</p>
                    </div>
                    <Switch
                      id="medicalRecordsUpdates"
                      checked={notificationSettings.medicalRecordsUpdates}
                      onCheckedChange={() => handleSwitchChange("medicalRecordsUpdates")}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="marketingEmails" className="text-base">Marketing Emails</Label>
                      <p className="text-sm text-gray-500">Receive promotional emails and newsletters</p>
                    </div>
                    <Switch
                      id="marketingEmails"
                      checked={notificationSettings.marketingEmails}
                      onCheckedChange={() => handleSwitchChange("marketingEmails")}
                    />
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="border-t border-gray-100 pt-4">
              <Button 
                onClick={() => handleSubmit("notification")}
                disabled={isSubmitting}
                className="ml-auto"
              >
                {isSubmitting ? "Saving..." : "Save Changes"}
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        <TabsContent value="appearance">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg font-medium">Appearance Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="theme">Theme</Label>
                  <div className="grid grid-cols-2 gap-4">
                    <div
                      className={`flex flex-col items-center p-4 rounded-lg border cursor-pointer ${
                        appearanceSettings.theme === "light" 
                          ? "border-health-blue bg-health-blue-light/10" 
                          : "border-gray-200 hover:border-health-blue"
                      }`}
                      onClick={() => handleSelectChange("appearance", "theme", "light")}
                    >
                      <Sun className="w-10 h-10 text-yellow-500 mb-2" />
                      <span className="font-medium">Light Mode</span>
                    </div>
                    <div
                      className={`flex flex-col items-center p-4 rounded-lg border cursor-pointer ${
                        appearanceSettings.theme === "dark" 
                          ? "border-health-blue bg-health-blue-light/10" 
                          : "border-gray-200 hover:border-health-blue"
                      }`}
                      onClick={() => handleSelectChange("appearance", "theme", "dark")}
                    >
                      <Moon className="w-10 h-10 text-indigo-500 mb-2" />
                      <span className="font-medium">Dark Mode</span>
                    </div>
                  </div>
                </div>
                
                <div className="pt-4 border-t border-gray-100 space-y-2">
                  <Label htmlFor="fontSize">Font Size</Label>
                  <Select
                    value={appearanceSettings.fontSize}
                    onValueChange={(value) => handleSelectChange("appearance", "fontSize", value)}
                  >
                    <SelectTrigger id="fontSize">
                      <SelectValue placeholder="Select font size" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="small">Small</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="large">Large</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="pt-4 border-t border-gray-100 space-y-2">
                  <Label htmlFor="language">Language</Label>
                  <div className="flex items-center space-x-3">
                    <Globe className="w-5 h-5 text-gray-500" />
                    <Select
                      value={appearanceSettings.language}
                      onValueChange={(value) => handleSelectChange("appearance", "language", value)}
                    >
                      <SelectTrigger id="language" className="flex-1">
                        <SelectValue placeholder="Select language" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="english">English</SelectItem>
                        <SelectItem value="spanish">Spanish</SelectItem>
                        <SelectItem value="french">French</SelectItem>
                        <SelectItem value="german">German</SelectItem>
                        <SelectItem value="chinese">Chinese</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="border-t border-gray-100 pt-4">
              <Button 
                onClick={() => handleSubmit("appearance")}
                disabled={isSubmitting}
                className="ml-auto"
              >
                {isSubmitting ? "Saving..." : "Save Changes"}
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        <TabsContent value="privacy">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg font-medium">Privacy & Security Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <h3 className="text-sm font-medium">Privacy Settings</h3>
                <div className="space-y-3">
                  <div className="space-y-2">
                    <Label htmlFor="profileVisibility">Profile Visibility</Label>
                    <div className="flex items-center space-x-3">
                      <UserCog className="w-5 h-5 text-gray-500" />
                      <Select
                        value={privacySettings.profileVisibility}
                        onValueChange={(value) => handleSelectChange("privacy", "profileVisibility", value)}
                      >
                        <SelectTrigger id="profileVisibility" className="flex-1">
                          <SelectValue placeholder="Select visibility" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">Everyone</SelectItem>
                          <SelectItem value="doctors">Doctors Only</SelectItem>
                          <SelectItem value="none">Private</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <Shield className="w-5 h-5 text-gray-500" />
                      <div>
                        <Label htmlFor="dataSharing" className="text-base">Data Sharing</Label>
                        <p className="text-sm text-gray-500">Share anonymized data for research purposes</p>
                      </div>
                    </div>
                    <Switch
                      id="dataSharing"
                      checked={privacySettings.dataSharing}
                      onCheckedChange={() => setPrivacySettings(prev => ({ ...prev, dataSharing: !prev.dataSharing }))}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <Bell className="w-5 h-5 text-gray-500" />
                      <div>
                        <Label htmlFor="analytics" className="text-base">Analytics</Label>
                        <p className="text-sm text-gray-500">Allow collection of usage data to improve services</p>
                      </div>
                    </div>
                    <Switch
                      id="analytics"
                      checked={privacySettings.analytics}
                      onCheckedChange={() => setPrivacySettings(prev => ({ ...prev, analytics: !prev.analytics }))}
                    />
                  </div>
                </div>
              </div>
              
              <div className="pt-4 border-t border-gray-100 space-y-4">
                <h3 className="text-sm font-medium">Security Settings</h3>
                <div className="space-y-4">
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <Lock className="w-5 h-5 text-gray-600" />
                      <div>
                        <h3 className="font-medium">Change Password</h3>
                        <p className="text-sm text-gray-500">Update your account password</p>
                      </div>
                    </div>
                    <Button variant="outline" className="mt-3 w-full" onClick={() => navigate("/profile")}>
                      Go to Password Settings
                    </Button>
                  </div>
                  
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <Smartphone className="w-5 h-5 text-gray-600" />
                      <div>
                        <h3 className="font-medium">Two-Factor Authentication</h3>
                        <p className="text-sm text-gray-500">Add an extra layer of security to your account</p>
                      </div>
                    </div>
                    <Button variant="outline" className="mt-3 w-full" onClick={() => {
                      toast({
                        title: "Feature not available",
                        description: "Two-factor authentication is not available in this demo.",
                      });
                    }}>
                      Set Up 2FA
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="border-t border-gray-100 pt-4">
              <Button 
                onClick={() => handleSubmit("privacy")}
                disabled={isSubmitting}
                className="ml-auto"
              >
                {isSubmitting ? "Saving..." : "Save Changes"}
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Settings;

function navigate(arg0: string) {
  window.location.href = arg0;
}
