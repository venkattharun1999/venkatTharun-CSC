
import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { 
  Heart, 
  Calendar, 
  FileText, 
  MessageSquare, 
  Users,
  Shield,
  Clock,
  Check
} from "lucide-react";

const Landing: React.FC = () => {
  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="bg-white border-b border-gray-200 fixed w-full z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <Link to="/" className="flex-shrink-0 flex items-center">
                <span className="text-2xl font-bold">
                  <span className="text-health-blue">E</span>-Health
                </span>
              </Link>
            </div>
            <div className="hidden md:ml-6 md:flex md:items-center md:space-x-4">
              <a href="#features" className="px-3 py-2 text-sm font-medium text-gray-700 hover:text-health-blue">
                Features
              </a>
              <a href="#how-it-works" className="px-3 py-2 text-sm font-medium text-gray-700 hover:text-health-blue">
                How It Works
              </a>
              <a href="#testimonials" className="px-3 py-2 text-sm font-medium text-gray-700 hover:text-health-blue">
                Testimonials
              </a>
              <a href="#faq" className="px-3 py-2 text-sm font-medium text-gray-700 hover:text-health-blue">
                FAQ
              </a>
            </div>
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Link to="/login">
                  <Button variant="outline" className="mr-2">
                    Login
                  </Button>
                </Link>
                <Link to="/register">
                  <Button className="bg-health-blue hover:bg-health-blue-dark">
                    Register
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="pt-24 pb-16 md:pt-32 md:pb-24 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-health-blue-light via-white to-health-green-light">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <div className="animate-fade-in">
              <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
                Modern Healthcare<br />Management Solution
              </h1>
              <p className="text-xl text-gray-600 mb-8">
                A comprehensive platform connecting patients and healthcare providers for better care coordination, simplified appointments, and secure medical records access.
              </p>
              <div className="space-y-3 md:space-y-0 md:space-x-4 md:flex">
                <Link to="/register" className="block md:inline-block">
                  <Button className="w-full md:w-auto bg-health-blue hover:bg-health-blue-dark py-6 px-8 text-lg rounded-xl">
                    Get Started
                  </Button>
                </Link>
                <Link to="/login" className="block md:inline-block">
                  <Button variant="outline" className="w-full md:w-auto py-6 px-8 text-lg rounded-xl">
                    Learn More
                  </Button>
                </Link>
              </div>
            </div>
            <div className="hidden md:block relative animate-slide-up">
              <img
                src="https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&q=80&w=1470"
                alt="Doctor using tablet"
                className="rounded-2xl shadow-lg"
              />
              <div className="absolute -bottom-6 -left-6 bg-white rounded-xl shadow-lg p-4 border border-gray-100">
                <div className="flex items-center space-x-3">
                  <div className="bg-health-green-light rounded-full p-3">
                    <Check className="h-6 w-6 text-health-green" />
                  </div>
                  <div>
                    <p className="font-medium">Appointment Confirmed</p>
                    <p className="text-sm text-gray-500">Tomorrow at 9:00 AM</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div id="features" className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Comprehensive Healthcare Management</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Our platform offers everything you need to manage your healthcare journey in one place
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="health-card animate-fade-in" style={{ animationDelay: "0.1s" }}>
              <div className="bg-health-blue-light w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                <Calendar className="h-6 w-6 text-health-blue" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Appointment Scheduling</h3>
              <p className="text-gray-600">
                Easily book, reschedule, or cancel appointments with your healthcare providers. Receive timely reminders.
              </p>
            </div>
            
            <div className="health-card animate-fade-in" style={{ animationDelay: "0.2s" }}>
              <div className="bg-health-green-light w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                <FileText className="h-6 w-6 text-health-green" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Medical Records</h3>
              <p className="text-gray-600">
                Access your medical history, test results, prescriptions, and diagnoses all in one secure location.
              </p>
            </div>
            
            <div className="health-card animate-fade-in" style={{ animationDelay: "0.3s" }}>
              <div className="bg-health-blue-light w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                <MessageSquare className="h-6 w-6 text-health-blue" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Secure Messaging</h3>
              <p className="text-gray-600">
                Communicate directly with your healthcare providers through our encrypted messaging system.
              </p>
            </div>
            
            <div className="health-card animate-fade-in" style={{ animationDelay: "0.4s" }}>
              <div className="bg-health-green-light w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                <Users className="h-6 w-6 text-health-green" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Doctor Directory</h3>
              <p className="text-gray-600">
                Find the right healthcare professional based on specialty, location, and availability.
              </p>
            </div>
            
            <div className="health-card animate-fade-in" style={{ animationDelay: "0.5s" }}>
              <div className="bg-health-blue-light w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                <Shield className="h-6 w-6 text-health-blue" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Data Security</h3>
              <p className="text-gray-600">
                Your health information is protected with enterprise-grade security and encryption protocols.
              </p>
            </div>
            
            <div className="health-card animate-fade-in" style={{ animationDelay: "0.6s" }}>
              <div className="bg-health-green-light w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                <Clock className="h-6 w-6 text-health-green" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Reminders & Alerts</h3>
              <p className="text-gray-600">
                Never miss an appointment or medication with our customizable reminder system.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* How it Works Section */}
      <div id="how-it-works" className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">How It Works</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Getting started with E-Health is simple and straightforward
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-white w-16 h-16 rounded-full flex items-center justify-center mb-4 mx-auto shadow-md">
                <span className="text-2xl font-bold text-health-blue">1</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">Create an Account</h3>
              <p className="text-gray-600">
                Register as a patient or healthcare provider with your basic information.
              </p>
            </div>
            
            <div className="text-center">
              <div className="bg-white w-16 h-16 rounded-full flex items-center justify-center mb-4 mx-auto shadow-md">
                <span className="text-2xl font-bold text-health-blue">2</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">Complete Your Profile</h3>
              <p className="text-gray-600">
                Add your medical history, preferences, and upload relevant documents.
              </p>
            </div>
            
            <div className="text-center">
              <div className="bg-white w-16 h-16 rounded-full flex items-center justify-center mb-4 mx-auto shadow-md">
                <span className="text-2xl font-bold text-health-blue">3</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">Start Managing Your Health</h3>
              <p className="text-gray-600">
                Book appointments, access records, and communicate with providers.
              </p>
            </div>
          </div>
          
          <div className="mt-16 text-center">
            <Link to="/register">
              <Button className="bg-health-blue hover:bg-health-blue-dark">
                Get Started Now
              </Button>
            </Link>
          </div>
        </div>
      </div>

      {/* Testimonials */}
      <div id="testimonials" className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">What Our Users Say</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Trusted by patients and healthcare providers around the world
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-gray-50 p-6 rounded-xl shadow-sm">
              <div className="flex items-center mb-4">
                <img
                  src="https://i.pravatar.cc/150?img=1"
                  alt="Testimonial"
                  className="w-12 h-12 rounded-full mr-4"
                />
                <div>
                  <h4 className="font-semibold">Sarah Johnson</h4>
                  <p className="text-sm text-gray-500">Patient</p>
                </div>
              </div>
              <p className="text-gray-600">
                "E-Health has completely transformed how I manage my healthcare. The ability to message my doctor directly and access my records anytime has been a game-changer."
              </p>
            </div>
            
            <div className="bg-gray-50 p-6 rounded-xl shadow-sm">
              <div className="flex items-center mb-4">
                <img
                  src="https://i.pravatar.cc/150?img=3"
                  alt="Testimonial"
                  className="w-12 h-12 rounded-full mr-4"
                />
                <div>
                  <h4 className="font-semibold">Dr. Michael Chen</h4>
                  <p className="text-sm text-gray-500">Cardiologist</p>
                </div>
              </div>
              <p className="text-gray-600">
                "As a doctor, this platform helps me stay organized and provide better care. The appointment management and secure messaging features save time and improve patient satisfaction."
              </p>
            </div>
            
            <div className="bg-gray-50 p-6 rounded-xl shadow-sm">
              <div className="flex items-center mb-4">
                <img
                  src="https://i.pravatar.cc/150?img=5"
                  alt="Testimonial"
                  className="w-12 h-12 rounded-full mr-4"
                />
                <div>
                  <h4 className="font-semibold">Emily Rodriguez</h4>
                  <p className="text-sm text-gray-500">Clinic Administrator</p>
                </div>
              </div>
              <p className="text-gray-600">
                "Managing our clinic has become significantly easier with E-Health. The analytics dashboard and appointment scheduling system have reduced our administrative workload."
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="py-16 px-4 sm:px-6 lg:px-8 bg-health-gradient">
        <div className="max-w-7xl mx-auto text-center">
          <div className="bg-gradient-to-r from-health-blue/10 to-health-green/10 p-12 rounded-2xl">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Ready to take control of your healthcare?
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
              Join thousands of patients and healthcare providers who are already benefiting from our platform.
            </p>
            <div className="space-y-4 sm:space-y-0 sm:space-x-4 sm:flex sm:justify-center">
              <Link to="/register">
                <Button className="w-full sm:w-auto bg-health-blue hover:bg-health-blue-dark">
                  Get Started
                </Button>
              </Link>
              <a href="#features">
                <Button variant="outline" className="w-full sm:w-auto">
                  Learn More
                </Button>
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-xl font-bold mb-4">
                <span className="text-health-blue">E</span>-Health
              </h3>
              <p className="text-gray-400">
                Modern healthcare management platform connecting patients and providers.
              </p>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2">
                <li><a href="#features" className="text-gray-400 hover:text-white">Features</a></li>
                <li><a href="#how-it-works" className="text-gray-400 hover:text-white">How It Works</a></li>
                <li><a href="#testimonials" className="text-gray-400 hover:text-white">Testimonials</a></li>
                <li><a href="#faq" className="text-gray-400 hover:text-white">FAQ</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4">Legal</h4>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-400 hover:text-white">Privacy Policy</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white">Terms of Service</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white">HIPAA Compliance</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white">Data Security</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4">Contact</h4>
              <ul className="space-y-2">
                <li className="text-gray-400">support@ehealth.com</li>
                <li className="text-gray-400">+1 (555) 123-4567</li>
                <li className="text-gray-400">123 Health Street, Medical City, MC 12345</li>
              </ul>
            </div>
          </div>
          
          <div className="mt-12 pt-8 border-t border-gray-700 text-center text-gray-400">
            <p>&copy; {new Date().getFullYear()} E-Health Inc. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Landing;
