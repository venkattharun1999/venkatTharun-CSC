
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";
import { mockUsers } from "@/data/mockData";
import { UserRole } from "@/types/auth";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

interface NewMessageDialogProps {
  isOpen: boolean;
  onClose: () => void;
  currentUserId: string;
  userRole: UserRole;
}

const NewMessageDialog: React.FC<NewMessageDialogProps> = ({ 
  isOpen, 
  onClose,
  currentUserId,
  userRole 
}) => {
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const [recipientId, setRecipientId] = useState("");
  const [message, setMessage] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Get list of potential recipients based on user role
  let recipients = [...mockUsers];
  
  // Filter out current user
  recipients = recipients.filter(u => u.id !== currentUserId);
  
  // If user is a patient, they can only message doctors
  if (userRole === "patient") {
    recipients = recipients.filter(u => u.role === "doctor");
  }
  
  // If user is a doctor, they can message patients and other doctors
  else if (userRole === "doctor") {
    recipients = recipients.filter(u => u.role === "patient" || u.role === "doctor");
  }
  
  // Admins can message anyone
  
  const handleSubmit = () => {
    if (!recipientId || !message) {
      toast({
        title: "Validation Error",
        description: "Please select a recipient and enter a message",
        variant: "destructive",
      });
      return;
    }
    
    setIsSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      toast({
        title: "Message Sent",
        description: "Your message has been sent successfully.",
      });
      setIsSubmitting(false);
      onClose();
      
      // In a real app, we would create a new conversation or add to an existing one
      // For now, just navigate to the messages page
      navigate("/messages");
    }, 1000);
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>New Message</DialogTitle>
          <DialogDescription>
            Send a message to a doctor or patient.
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="recipient">Recipient</Label>
            <Select value={recipientId} onValueChange={setRecipientId}>
              <SelectTrigger id="recipient">
                <SelectValue placeholder="Select recipient" />
              </SelectTrigger>
              <SelectContent>
                {recipients.map((recipient) => (
                  <SelectItem 
                    key={recipient.id} 
                    value={recipient.id}
                    className="flex items-center"
                  >
                    <div className="flex items-center">
                      <Avatar className="h-6 w-6 mr-2">
                        <AvatarImage src={recipient.profilePicture} />
                        <AvatarFallback>{recipient.name.split(" ").map(n => n[0]).join("")}</AvatarFallback>
                      </Avatar>
                      {recipient.name} {recipient.role === "doctor" ? `(Doctor)` : recipient.role === "patient" ? `(Patient)` : `(Admin)`}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="message">Message</Label>
            <Textarea 
              id="message" 
              placeholder="Type your message here..."
              rows={5}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
            />
          </div>
        </div>
        
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSubmit} disabled={isSubmitting}>
            {isSubmitting ? "Sending..." : "Send Message"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default NewMessageDialog;
