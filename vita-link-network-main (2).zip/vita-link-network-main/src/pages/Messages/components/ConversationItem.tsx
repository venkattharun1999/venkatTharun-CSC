import React from "react";
import { useNavigate } from "react-router-dom";
import { Conversation } from "@/types/message";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

interface ConversationItemProps {
  conversation: Conversation;
  currentUserId: string;
}

const ConversationItem: React.FC<ConversationItemProps> = ({ conversation, currentUserId }) => {
  const navigate = useNavigate();
  
  // Find the other participant (not the current user)
  const currentUserIndex = conversation.participantIds.indexOf(currentUserId);
  const otherParticipantIndex = currentUserIndex === 0 ? 1 : 0;
  
  const otherParticipantName = conversation.participantNames[otherParticipantIndex];
  const otherParticipantAvatar = conversation.participantAvatars[otherParticipantIndex];
  
  // Format date
  const formatMessageTime = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    
    // If today, show time
    if (date.toDateString() === now.toDateString()) {
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }
    
    // If this year, show month and day
    if (date.getFullYear() === now.getFullYear()) {
      return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
    }
    
    // Otherwise show full date
    return date.toLocaleDateString([], { year: 'numeric', month: 'short', day: 'numeric' });
  };
  
  return (
    <div 
      className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-all cursor-pointer"
      onClick={() => navigate(`/messages/${conversation.id}`)}
    >
      <div className="flex items-center">
        <Avatar className="h-12 w-12">
          <AvatarImage src={otherParticipantAvatar} />
          <AvatarFallback>
            {otherParticipantName.split(" ").map(n => n[0]).join("")}
          </AvatarFallback>
        </Avatar>
        <div className="ml-4">
          <h3 className="font-medium">{otherParticipantName}</h3>
          <p className="text-sm text-gray-500 line-clamp-1">{conversation.lastMessage}</p>
        </div>
      </div>
      <div className="flex flex-col items-end gap-1">
        <span className="text-xs text-gray-500">{formatMessageTime(conversation.lastMessageTime)}</span>
        {conversation.unreadCount > 0 && (
          <Badge className="bg-health-blue">{conversation.unreadCount}</Badge>
        )}
      </div>
    </div>
  );
};

export default ConversationItem;
