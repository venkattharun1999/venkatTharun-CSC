import React, { useState, useEffect, useRef } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { Conversation as ConversationType, Message } from "@/types/message";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardFooter 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  ArrowLeft, 
  Send, 
  Paperclip, 
  MoreVertical, 
  MessageSquare,
  AlertCircle
} from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useToast } from "@/hooks/use-toast";

// Mock conversations
const mockConversations: ConversationType[] = [
  {
    id: "conv1",
    participantIds: ["patient1", "doctor1"],
    participantNames: ["John Doe", "Dr. Sarah Johnson"],
    participantAvatars: ["https://i.pravatar.cc/150?img=1", "https://i.pravatar.cc/150?img=2"],
    lastMessage: "Thank you for the prescription. When should I come for a follow-up?",
    lastMessageTime: "2025-04-08T10:30:00Z",
    unreadCount: 1
  },
  {
    id: "conv2",
    participantIds: ["patient1", "doctor2"],
    participantNames: ["John Doe", "Dr. Michael Chen"],
    participantAvatars: ["https://i.pravatar.cc/150?img=1", "https://i.pravatar.cc/150?img=3"],
    lastMessage: "Your lab results look good. Keep up with the medication.",
    lastMessageTime: "2025-04-07T14:15:00Z",
    unreadCount: 0
  },
  {
    id: "conv3",
    participantIds: ["patient1", "doctor3"],
    participantNames: ["John Doe", "Dr. James Wilson"],
    participantAvatars: ["https://i.pravatar.cc/150?img=1", "https://i.pravatar.cc/150?img=4"],
    lastMessage: "I've uploaded your X-ray results to your medical records.",
    lastMessageTime: "2025-04-05T09:45:00Z",
    unreadCount: 0
  }
];

// Mock messages
const mockMessages: Message[] = [
  {
    id: "msg1",
    senderId: "doctor1",
    senderName: "Dr. Sarah Johnson",
    senderAvatar: "https://i.pravatar.cc/150?img=2",
    receiverId: "patient1",
    content: "Hello John, I've reviewed your test results. Your blood pressure is still a bit high.",
    timestamp: "2025-04-07T09:00:00Z",
    isRead: true
  },
  {
    id: "msg2",
    senderId: "patient1",
    senderName: "John Doe",
    senderAvatar: "https://i.pravatar.cc/150?img=1",
    receiverId: "doctor1",
    content: "Thank you for checking, doctor. Should I increase my medication dosage?",
    timestamp: "2025-04-07T09:15:00Z",
    isRead: true
  },
  {
    id: "msg3",
    senderId: "doctor1",
    senderName: "Dr. Sarah Johnson",
    senderAvatar: "https://i.pravatar.cc/150?img=2",
    receiverId: "patient1",
    content: "Let's not change the dosage yet. I've sent a prescription for a new medication that should help. Take it once daily in the morning.",
    timestamp: "2025-04-07T09:30:00Z",
    isRead: true
  },
  {
    id: "msg4",
    senderId: "patient1",
    senderName: "John Doe",
    senderAvatar: "https://i.pravatar.cc/150?img=1",
    receiverId: "doctor1",
    content: "Thank you for the prescription. When should I come for a follow-up?",
    timestamp: "2025-04-08T10:30:00Z",
    isRead: false
  }
];

const Conversation: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toast } = useToast();
  
  const [newMessage, setNewMessage] = useState("");
  const [messages, setMessages] = useState<Message[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    if (!user) return;
    
    // Find conversation
    const conversation = mockConversations.find(conv => conv.id === id);
    if (!conversation) return;
    
    // Get messages for this conversation
    const conversationMessages = mockMessages.filter(
      msg => 
        (conversation.participantIds.includes(msg.senderId) && 
         conversation.participantIds.includes(msg.receiverId))
    );
    
    setMessages(conversationMessages);
    
    // Scroll to bottom
    scrollToBottom();
  }, [id, user]);
  
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };
  
  if (!user) return null;
  
  const conversation = mockConversations.find(conv => conv.id === id);
  
  if (!conversation) {
    return (
      <div className="flex flex-col items-center justify-center py-12">
        <AlertCircle className="h-12 w-12 text-health-red mb-4" />
        <h1 className="text-2xl font-bold mb-2">Conversation Not Found</h1>
        <p className="text-gray-600 mb-4">The conversation you're looking for doesn't exist or has been removed.</p>
        <Button onClick={() => navigate("/messages")}>
          Go Back to Messages
        </Button>
      </div>
    );
  }
  
  // Find the other participant (not the current user)
  const currentUserIndex = conversation.participantIds.indexOf(user.id);
  const otherParticipantIndex = currentUserIndex === 0 ? 1 : 0;
  
  const otherParticipantId = conversation.participantIds[otherParticipantIndex];
  const otherParticipantName = conversation.participantNames[otherParticipantIndex];
  const otherParticipantAvatar = conversation.participantAvatars[otherParticipantIndex];
  
  const handleSendMessage = () => {
    if (!newMessage.trim()) return;
    
    // Create new message
    const message: Message = {
      id: `msg${Date.now()}`,
      senderId: user.id,
      senderName: user.name,
      senderAvatar: user.profilePicture,
      receiverId: otherParticipantId,
      content: newMessage,
      timestamp: new Date().toISOString(),
      isRead: false
    };
    
    // Add message to state
    setMessages([...messages, message]);
    
    // Clear input
    setNewMessage("");
    
    // Scroll to bottom
    setTimeout(scrollToBottom, 100);
    
    // Show toast
    toast({
      title: "Message Sent",
      description: "Your message has been sent successfully.",
    });
  };
  
  // Format date
  const formatMessageTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };
  
  // Format date for message groups
  const formatMessageDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    
    // If today
    if (date.toDateString() === now.toDateString()) {
      return "Today";
    }
    
    // If yesterday
    const yesterday = new Date(now);
    yesterday.setDate(now.getDate() - 1);
    if (date.toDateString() === yesterday.toDateString()) {
      return "Yesterday";
    }
    
    // Otherwise show full date
    return date.toLocaleDateString([], { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
  };
  
  // Group messages by date
  const messageGroups: { date: string; messages: Message[] }[] = [];
  let currentDate = "";
  
  messages.forEach(message => {
    const messageDate = new Date(message.timestamp).toDateString();
    
    if (messageDate !== currentDate) {
      currentDate = messageDate;
      messageGroups.push({
        date: formatMessageDate(message.timestamp),
        messages: [message]
      });
    } else {
      messageGroups[messageGroups.length - 1].messages.push(message);
    }
  });
  
  return (
    <div className="animate-fade-in h-[calc(100vh-10rem)] flex flex-col">
      <div className="flex items-center gap-4 mb-4">
        <Button variant="ghost" size="icon" onClick={() => navigate("/messages")}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-2xl font-bold">Messages</h1>
      </div>
      
      <Card className="flex-1 flex flex-col overflow-hidden">
        <CardHeader className="pb-3 border-b">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Avatar className="h-10 w-10">
                <AvatarImage src={otherParticipantAvatar} />
                <AvatarFallback>
                  {otherParticipantName.split(" ").map(n => n[0]).join("")}
                </AvatarFallback>
              </Avatar>
              <div className="ml-3">
                <CardTitle className="text-base font-medium">{otherParticipantName}</CardTitle>
                <p className="text-xs text-gray-500">
                  {conversation.participantIds.includes("doctor1") ? "Doctor" : 
                   conversation.participantIds.includes("patient1") ? "Patient" : "Admin"}
                </p>
              </div>
            </div>
            <Button variant="ghost" size="icon">
              <MoreVertical className="h-5 w-5" />
            </Button>
          </div>
        </CardHeader>
        <CardContent className="flex-1 overflow-y-auto p-4 space-y-6">
          {messageGroups.length > 0 ? (
            messageGroups.map((group, groupIndex) => (
              <div key={groupIndex} className="space-y-4">
                <div className="flex justify-center">
                  <span className="text-xs bg-gray-100 text-gray-500 px-3 py-1 rounded-full">
                    {group.date}
                  </span>
                </div>
                
                {group.messages.map((message, messageIndex) => (
                  <div 
                    key={message.id}
                    className={`flex ${message.senderId === user.id ? "justify-end" : "justify-start"}`}
                  >
                    <div className="flex max-w-[80%]">
                      {message.senderId !== user.id && (
                        <Avatar className="h-8 w-8 mr-2 mt-1">
                          <AvatarImage src={message.senderAvatar} />
                          <AvatarFallback>
                            {message.senderName.split(" ").map(n => n[0]).join("")}
                          </AvatarFallback>
                        </Avatar>
                      )}
                      <div>
                        <div 
                          className={`p-3 rounded-lg ${
                            message.senderId === user.id 
                              ? "bg-health-blue text-white rounded-br-none" 
                              : "bg-gray-100 text-gray-800 rounded-bl-none"
                          }`}
                        >
                          {message.content}
                        </div>
                        <div 
                          className={`text-xs mt-1 ${
                            message.senderId === user.id ? "text-right" : ""
                          } text-gray-500`}
                        >
                          {formatMessageTime(message.timestamp)}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ))
          ) : (
            <div className="h-full flex flex-col items-center justify-center">
              <MessageSquare className="h-12 w-12 text-gray-300 mb-4" />
              <h3 className="text-lg font-medium">No Messages Yet</h3>
              <p className="text-sm text-gray-500 mt-1">
                Start the conversation by sending a message below.
              </p>
            </div>
          )}
          <div ref={messagesEndRef} />
        </CardContent>
        <CardFooter className="border-t p-4">
          <div className="flex items-center w-full gap-2">
            <Button variant="outline" size="icon">
              <Paperclip className="h-4 w-4" />
            </Button>
            <Input
              placeholder="Type a message..."
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage();
                }
              }}
              className="flex-1"
            />
            <Button 
              disabled={!newMessage.trim()} 
              onClick={handleSendMessage}
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </CardFooter>
      </Card>
    </div>
  );
};

export default Conversation;
