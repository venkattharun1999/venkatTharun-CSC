
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { Conversation } from "@/types/message";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, Plus, MessageSquare } from "lucide-react";
import ConversationItem from "./components/ConversationItem";
import NewMessageDialog from "./components/NewMessageDialog";

// Mock conversations
const mockConversations: Conversation[] = [
  {
    id: "conv1",
    participantIds: ["patient1", "doctor1"],
    participantNames: ["John Doe", "Dr. Sarah Johnson"],
    participantAvatars: ["https://i.pravatar.cc/150?img=1", "https://i.pravatar.cc/150?img=2"],
    lastMessage: "Thank you for the prescription. When should I come for a follow-up?",
    lastMessageTime: "2025-04-08T10:30:00Z",
    unreadCount: 1
  },
  {
    id: "conv2",
    participantIds: ["patient1", "doctor2"],
    participantNames: ["John Doe", "Dr. Michael Chen"],
    participantAvatars: ["https://i.pravatar.cc/150?img=1", "https://i.pravatar.cc/150?img=3"],
    lastMessage: "Your lab results look good. Keep up with the medication.",
    lastMessageTime: "2025-04-07T14:15:00Z",
    unreadCount: 0
  },
  {
    id: "conv3",
    participantIds: ["patient1", "doctor3"],
    participantNames: ["John Doe", "Dr. James Wilson"],
    participantAvatars: ["https://i.pravatar.cc/150?img=1", "https://i.pravatar.cc/150?img=4"],
    lastMessage: "I've uploaded your X-ray results to your medical records.",
    lastMessageTime: "2025-04-05T09:45:00Z",
    unreadCount: 0
  }
];

const Messages: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");
  const [showNewMessageDialog, setShowNewMessageDialog] = useState(false);
  
  if (!user) return null;
  
  let conversations = [...mockConversations];
  
  // Filter based on user role
  conversations = conversations.filter(conv => 
    conv.participantIds.includes(user.id)
  );
  
  // Filter by search query
  if (searchQuery) {
    const query = searchQuery.toLowerCase();
    conversations = conversations.filter(conv => 
      // Find the other participant (not the current user)
      conv.participantNames.find(name => 
        name.toLowerCase().includes(query) && 
        conv.participantNames.indexOf(name) !== conv.participantIds.indexOf(user.id)
      )
    );
  }
  
  // Sort by last message time (newest first)
  conversations.sort((a, b) => new Date(b.lastMessageTime).getTime() - new Date(a.lastMessageTime).getTime());
  
  // Calculate total unread messages
  const totalUnread = conversations.reduce((total, conv) => total + conv.unreadCount, 0);
  
  return (
    <div className="animate-fade-in space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div className="flex items-center gap-2">
          <h1 className="text-2xl font-bold">Messages</h1>
          {totalUnread > 0 && (
            <span className="bg-health-red text-white text-xs font-medium px-2.5 py-0.5 rounded-full">
              {totalUnread}
            </span>
          )}
        </div>
        
        <div className="flex items-center gap-2">
          <div className="relative flex-grow">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
            <Input
              type="search"
              placeholder="Search conversations..."
              className="pl-8"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          
          <Button 
            size="sm" 
            onClick={() => setShowNewMessageDialog(true)}
          >
            <Plus size={16} className="mr-2" />
            New Message
          </Button>
        </div>
      </div>
      
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg font-medium">Your Conversations</CardTitle>
        </CardHeader>
        <CardContent>
          {conversations.length > 0 ? (
            <div className="space-y-2">
              {conversations.map(conversation => (
                <ConversationItem 
                  key={conversation.id}
                  conversation={conversation}
                  currentUserId={user.id}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-10">
              <MessageSquare className="h-12 w-12 mx-auto text-gray-300" />
              <h3 className="mt-2 text-lg font-medium">No Conversations</h3>
              <p className="text-sm text-gray-500 mt-1 mb-4">
                {searchQuery
                  ? "No conversations match your search criteria."
                  : "You don't have any conversations yet."}
              </p>
              <Button onClick={() => setShowNewMessageDialog(true)}>
                Start a New Conversation
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
      
      <NewMessageDialog
        isOpen={showNewMessageDialog}
        onClose={() => setShowNewMessageDialog(false)}
        currentUserId={user.id}
        userRole={user.role}
      />
    </div>
  );
};

export default Messages;
