
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { mockUsers } from "@/data/mockData";
import { RecordType } from "@/types/medical-record";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardFooter 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, User, Plus, X } from "lucide-react";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const NewRecord: React.FC = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toast } = useToast();
  
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [type, setType] = useState<RecordType>("diagnosis");
  const [patientId, setPatientId] = useState("");
  const [prescriptions, setPrescriptions] = useState<Array<{name: string; dosage: string; frequency: string; duration: string}>>([]);
  const [files, setFiles] = useState<FileList | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  if (!user) return null;
  
  // Only doctors and admins can create medical records
  if (user.role !== "doctor" && user.role !== "admin") {
    navigate("/medical-records");
    return null;
  }
  
  const patients = mockUsers.filter(u => u.role === "patient");
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!title || !description || !type || !patientId) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }
    
    setIsSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      toast({
        title: "Record Created",
        description: "The medical record has been created successfully.",
      });
      setIsSubmitting(false);
      navigate("/medical-records");
    }, 1000);
  };
  
  const addPrescription = () => {
    setPrescriptions([...prescriptions, { name: "", dosage: "", frequency: "", duration: "" }]);
  };
  
  const removePrescription = (index: number) => {
    const updated = [...prescriptions];
    updated.splice(index, 1);
    setPrescriptions(updated);
  };
  
  const updatePrescription = (index: number, field: string, value: string) => {
    const updated = [...prescriptions];
    updated[index] = { ...updated[index], [field]: value };
    setPrescriptions(updated);
  };
  
  return (
    <div className="animate-fade-in space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => navigate("/medical-records")}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-2xl font-bold">Create New Medical Record</h1>
      </div>
      
      <form onSubmit={handleSubmit}>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg font-medium">Record Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="type">Record Type</Label>
                    <Select value={type} onValueChange={(value: RecordType) => setType(value)}>
                      <SelectTrigger id="type">
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="diagnosis">Diagnosis</SelectItem>
                        <SelectItem value="prescription">Prescription</SelectItem>
                        <SelectItem value="lab-result">Lab Result</SelectItem>
                        <SelectItem value="radiology">Radiology</SelectItem>
                        <SelectItem value="note">Note</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="patient">Patient</Label>
                    <Select value={patientId} onValueChange={setPatientId}>
                      <SelectTrigger id="patient">
                        <SelectValue placeholder="Select patient" />
                      </SelectTrigger>
                      <SelectContent>
                        {patients.map((patient) => (
                          <SelectItem key={patient.id} value={patient.id}>
                            {patient.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="title">Title</Label>
                  <Input 
                    id="title" 
                    placeholder="Record title..." 
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea 
                    id="description" 
                    placeholder="Detailed description..." 
                    rows={4}
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                  />
                </div>
                
                {(type === "prescription" || type === "diagnosis") && (
                  <div className="space-y-3 pt-2">
                    <div className="flex items-center justify-between">
                      <Label>Prescriptions</Label>
                      <Button 
                        type="button" 
                        variant="outline" 
                        size="sm"
                        onClick={addPrescription}
                      >
                        <Plus size={14} className="mr-1" />
                        Add Prescription
                      </Button>
                    </div>
                    
                    {prescriptions.length > 0 ? (
                      <div className="space-y-4">
                        {prescriptions.map((prescription, index) => (
                          <div key={index} className="grid grid-cols-1 md:grid-cols-2 gap-3 p-3 border rounded-lg relative">
                            <Button 
                              type="button"
                              variant="ghost" 
                              size="icon"
                              className="absolute top-2 right-2 h-6 w-6"
                              onClick={() => removePrescription(index)}
                            >
                              <X size={14} />
                            </Button>
                            
                            <div className="space-y-2">
                              <Label htmlFor={`prescription-name-${index}`}>Medication Name</Label>
                              <Input 
                                id={`prescription-name-${index}`} 
                                value={prescription.name}
                                onChange={(e) => updatePrescription(index, "name", e.target.value)}
                                placeholder="Medication name..."
                              />
                            </div>
                            
                            <div className="space-y-2">
                              <Label htmlFor={`prescription-dosage-${index}`}>Dosage</Label>
                              <Input 
                                id={`prescription-dosage-${index}`} 
                                value={prescription.dosage}
                                onChange={(e) => updatePrescription(index, "dosage", e.target.value)}
                                placeholder="e.g. 10mg"
                              />
                            </div>
                            
                            <div className="space-y-2">
                              <Label htmlFor={`prescription-frequency-${index}`}>Frequency</Label>
                              <Input 
                                id={`prescription-frequency-${index}`} 
                                value={prescription.frequency}
                                onChange={(e) => updatePrescription(index, "frequency", e.target.value)}
                                placeholder="e.g. Once daily"
                              />
                            </div>
                            
                            <div className="space-y-2">
                              <Label htmlFor={`prescription-duration-${index}`}>Duration</Label>
                              <Input 
                                id={`prescription-duration-${index}`} 
                                value={prescription.duration}
                                onChange={(e) => updatePrescription(index, "duration", e.target.value)}
                                placeholder="e.g. 2 weeks"
                              />
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-6 border border-dashed rounded-lg">
                        <p className="text-gray-500">No prescriptions added yet</p>
                        <Button 
                          type="button" 
                          variant="ghost" 
                          size="sm"
                          className="mt-2"
                          onClick={addPrescription}
                        >
                          <Plus size={14} className="mr-1" />
                          Add Prescription
                        </Button>
                      </div>
                    )}
                  </div>
                )}
                
                {(type === "lab-result" || type === "radiology") && (
                  <div className="space-y-2 pt-2">
                    <Label htmlFor="files">Attach Files</Label>
                    <Input 
                      id="files" 
                      type="file" 
                      multiple
                      onChange={(e) => setFiles(e.target.files)}
                    />
                    <p className="text-sm text-gray-500">Upload relevant files such as lab reports, X-rays, or other documents.</p>
                  </div>
                )}
              </CardContent>
              <CardFooter className="border-t border-gray-100 pt-4">
                <Button 
                  type="submit"
                  className="ml-auto"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? "Creating Record..." : "Create Record"}
                </Button>
              </CardFooter>
            </Card>
          </div>
          
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg font-medium">Patient Information</CardTitle>
            </CardHeader>
            <CardContent>
              {patientId ? (
                <div className="space-y-4">
                  {(() => {
                    const patient = patients.find(p => p.id === patientId);
                    if (!patient) return <p className="text-gray-500">Patient not found</p>;
                    
                    return (
                      <>
                        <div className="flex items-center">
                          <User className="h-10 w-10 text-gray-400 bg-gray-100 p-2 rounded-full" />
                          <div className="ml-3">
                            <h3 className="font-medium">{patient.name}</h3>
                            <p className="text-sm text-gray-500">Patient ID: {patient.id.substring(0, 8)}</p>
                          </div>
                        </div>
                        
                        <div className="text-sm pt-4">
                          <p className="flex justify-between py-1 border-b border-gray-100">
                            <span className="text-gray-500">Email:</span>
                            <span className="font-medium">{patient.email}</span>
                          </p>
                          {patient.dateOfBirth && (
                            <p className="flex justify-between py-1 border-b border-gray-100">
                              <span className="text-gray-500">Date of Birth:</span>
                              <span className="font-medium">{patient.dateOfBirth}</span>
                            </p>
                          )}
                          {patient.bloodType && (
                            <p className="flex justify-between py-1 border-b border-gray-100">
                              <span className="text-gray-500">Blood Type:</span>
                              <span className="font-medium">{patient.bloodType}</span>
                            </p>
                          )}
                          {patient.phone && (
                            <p className="flex justify-between py-1 border-b border-gray-100">
                              <span className="text-gray-500">Phone:</span>
                              <span className="font-medium">{patient.phone}</span>
                            </p>
                          )}
                        </div>
                        
                        {patient.medicalHistory && (
                          <div className="pt-4">
                            <h3 className="font-medium mb-2 text-sm">Medical History</h3>
                            <p className="text-sm text-gray-700">{patient.medicalHistory}</p>
                          </div>
                        )}
                        
                        <div className="flex flex-col gap-2 pt-4">
                          <Button variant="outline" className="w-full" onClick={() => navigate("/medical-records")}>
                            View Patient Records
                          </Button>
                        </div>
                      </>
                    );
                  })()}
                </div>
              ) : (
                <div className="text-center py-6">
                  <User className="h-12 w-12 mx-auto text-gray-300" />
                  <h3 className="mt-2 text-lg font-medium">No Patient Selected</h3>
                  <p className="text-sm text-gray-500 mt-1">
                    Please select a patient to view their information.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </form>
    </div>
  );
};

export default NewRecord;
