
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { MedicalRecord } from "@/types/medical-record";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  FileText,
  Filter,
  Plus,
  Search
} from "lucide-react";
import { Input } from "@/components/ui/input";
import RecordItem from "./components/RecordItem";

// Mock medical records
const mockMedicalRecords: MedicalRecord[] = [
  {
    id: "record1",
    patientId: "patient1",
    doctorId: "doctor1",
    doctorName: "Dr. Sarah Johnson",
    type: "diagnosis",
    title: "Hypertension Diagnosis",
    description: "Patient diagnosed with Stage 1 Hypertension. Blood pressure reading was 140/90 mmHg.",
    date: "2025-03-15",
    prescriptions: [
      {
        name: "Lisinopril",
        dosage: "10mg",
        frequency: "Once daily",
        duration: "3 months"
      }
    ]
  },
  {
    id: "record2",
    patientId: "patient1",
    doctorId: "doctor2",
    doctorName: "Dr. Michael Chen",
    type: "lab-result",
    title: "Blood Work Results",
    description: "Complete blood count and metabolic panel. All results within normal ranges except for slightly elevated cholesterol.",
    date: "2025-02-28",
    attachments: [
      {
        name: "CBC_Results.pdf",
        url: "#",
        type: "application/pdf"
      }
    ]
  },
  {
    id: "record3",
    patientId: "patient1",
    doctorId: "doctor1",
    doctorName: "Dr. Sarah Johnson",
    type: "prescription",
    title: "Medication Prescription",
    description: "Prescription for blood pressure management and cholesterol control.",
    date: "2025-03-15",
    prescriptions: [
      {
        name: "Lisinopril",
        dosage: "10mg",
        frequency: "Once daily",
        duration: "3 months"
      },
      {
        name: "Atorvastatin",
        dosage: "20mg",
        frequency: "Once daily at bedtime",
        duration: "6 months"
      }
    ]
  },
  {
    id: "record4",
    patientId: "patient1",
    doctorId: "doctor3",
    doctorName: "Dr. James Wilson",
    type: "radiology",
    title: "Chest X-Ray",
    description: "Chest X-ray performed to rule out pneumonia. Results show clear lung fields with no abnormalities detected.",
    date: "2025-01-10",
    attachments: [
      {
        name: "Chest_XRay.jpg",
        url: "#",
        type: "image/jpeg"
      },
      {
        name: "Radiology_Report.pdf",
        url: "#",
        type: "application/pdf"
      }
    ]
  },
  {
    id: "record5",
    patientId: "patient1",
    doctorId: "doctor1",
    doctorName: "Dr. Sarah Johnson",
    type: "note",
    title: "Follow-up Visit Notes",
    description: "Patient reports improved symptoms. Blood pressure has decreased to 130/85 mmHg. Continue current treatment plan.",
    date: "2025-04-01"
  }
];

const MedicalRecords: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [filter, setFilter] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState("");
  
  if (!user) return null;
  
  let records = [...mockMedicalRecords];
  
  // If user is a patient, they can only see their records
  // If user is a doctor, they can see records they created
  // If user is an admin, they can see all records
  if (user.role === "patient") {
    records = records.filter(record => record.patientId === user.id);
  } else if (user.role === "doctor") {
    records = records.filter(record => record.doctorId === user.id);
  }
  
  // Filter by type if not "all"
  if (filter !== "all") {
    records = records.filter(record => record.type === filter);
  }
  
  // Filter by search query
  if (searchQuery) {
    const query = searchQuery.toLowerCase();
    records = records.filter(record => 
      record.title.toLowerCase().includes(query) || 
      record.description.toLowerCase().includes(query) ||
      record.doctorName.toLowerCase().includes(query)
    );
  }
  
  // Sort by date (newest first)
  records.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  
  return (
    <div className="animate-fade-in space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <h1 className="text-2xl font-bold">Medical Records</h1>
        
        <div className="flex items-center gap-2">
          <div className="relative flex-grow">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
            <Input
              type="search"
              placeholder="Search records..."
              className="pl-8"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          
          {(user.role === "doctor" || user.role === "admin") && (
            <Button 
              size="sm" 
              onClick={() => navigate("/medical-records/new")}
            >
              <Plus size={16} className="mr-2" />
              New Record
            </Button>
          )}
        </div>
      </div>
      
      <Tabs defaultValue="all" className="w-full" onValueChange={setFilter}>
        <TabsList className="grid grid-cols-3 md:grid-cols-6 mb-4">
          <TabsTrigger value="all">All</TabsTrigger>
          <TabsTrigger value="diagnosis">Diagnoses</TabsTrigger>
          <TabsTrigger value="prescription">Prescriptions</TabsTrigger>
          <TabsTrigger value="lab-result">Lab Results</TabsTrigger>
          <TabsTrigger value="radiology">Radiology</TabsTrigger>
          <TabsTrigger value="note">Notes</TabsTrigger>
        </TabsList>
        
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg font-medium">
              {filter === "all" ? "All Records" : 
               filter === "diagnosis" ? "Diagnoses" :
               filter === "prescription" ? "Prescriptions" :
               filter === "lab-result" ? "Lab Results" :
               filter === "radiology" ? "Radiology" :
               "Notes"}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {records.length > 0 ? (
              <div className="space-y-4">
                {records.map(record => (
                  <RecordItem 
                    key={record.id}
                    record={record}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-10">
                <FileText className="h-12 w-12 mx-auto text-gray-300" />
                <h3 className="mt-2 text-lg font-medium">No Records Found</h3>
                <p className="text-sm text-gray-500 mt-1 mb-4">
                  {searchQuery
                    ? "No records match your search criteria."
                    : filter === "all"
                    ? "You don't have any medical records yet."
                    : `You don't have any ${filter.replace('-', ' ')} records yet.`}
                </p>
                {(user.role === "doctor" || user.role === "admin") && (
                  <Button onClick={() => navigate("/medical-records/new")}>
                    Create New Record
                  </Button>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </Tabs>
    </div>
  );
};

export default MedicalRecords;
