
import React from "react";
import { useNavigate } from "react-router-dom";
import { MedicalRecord } from "@/types/medical-record";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  FileText, 
  Pill, 
  Microscope, 
  Activity, 
  StickyNote, 
  Download, 
  ChevronRight
} from "lucide-react";

interface RecordItemProps {
  record: MedicalRecord;
}

const RecordItem: React.FC<RecordItemProps> = ({ record }) => {
  const navigate = useNavigate();
  
  // Format date
  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };
  
  // Get icon based on record type
  const getTypeIcon = () => {
    switch (record.type) {
      case "diagnosis":
        return <Activity size={16} />;
      case "prescription":
        return <Pill size={16} />;
      case "lab-result":
        return <Microscope size={16} />;
      case "radiology":
        return <FileText size={16} />;
      case "note":
        return <StickyNote size={16} />;
      default:
        return <FileText size={16} />;
    }
  };
  
  // Get color based on record type
  const getTypeColor = () => {
    switch (record.type) {
      case "diagnosis":
        return "bg-health-blue-light text-health-blue";
      case "prescription":
        return "bg-health-green-light text-health-green";
      case "lab-result":
        return "bg-purple-100 text-purple-600";
      case "radiology":
        return "bg-amber-100 text-amber-600";
      case "note":
        return "bg-gray-100 text-gray-600";
      default:
        return "bg-gray-100 text-gray-600";
    }
  };
  
  return (
    <div 
      className="flex flex-col md:flex-row md:items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-all cursor-pointer"
      onClick={() => navigate(`/medical-records/${record.id}`)}
    >
      <div className="mb-3 md:mb-0">
        <div className="flex items-center mb-2">
          <Badge variant="outline" className={`${getTypeColor()} border-0`}>
            <span className="mr-1">{getTypeIcon()}</span>
            {record.type.charAt(0).toUpperCase() + record.type.slice(1).replace('-', ' ')}
          </Badge>
          <span className="text-sm text-gray-500 ml-2">{formatDate(record.date)}</span>
        </div>
        <h3 className="font-medium">{record.title}</h3>
        <p className="text-sm text-gray-600 line-clamp-2">{record.description}</p>
        <p className="text-xs text-gray-500 mt-1">By {record.doctorName}</p>
      </div>
      <div className="flex items-center gap-2">
        {record.attachments && record.attachments.length > 0 && (
          <Button 
            variant="outline" 
            size="sm"
            onClick={(e) => {
              e.stopPropagation();
              // Download logic would go here
            }}
          >
            <Download size={14} className="mr-1" />
            {record.attachments.length} {record.attachments.length === 1 ? 'File' : 'Files'}
          </Button>
        )}
        <Button variant="ghost" size="icon">
          <ChevronRight size={16} />
        </Button>
      </div>
    </div>
  );
};

export default RecordItem;
