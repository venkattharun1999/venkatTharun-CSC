
import React from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardFooter 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  ArrowLeft, 
  Calendar, 
  User,
  FileText,
  Download,
  Printer,
  Microscope,
  Pill,
  AlertCircle
} from "lucide-react";
import { Badge } from "@/components/ui/badge";

// Reusing the mock medical records
const mockMedicalRecords = [
  {
    id: "record1",
    patientId: "patient1",
    doctorId: "doctor1",
    doctorName: "Dr. Sarah Johnson",
    type: "diagnosis",
    title: "Hypertension Diagnosis",
    description: "Patient diagnosed with Stage 1 Hypertension. Blood pressure reading was 140/90 mmHg.",
    date: "2025-03-15",
    prescriptions: [
      {
        name: "Lisinopril",
        dosage: "10mg",
        frequency: "Once daily",
        duration: "3 months"
      }
    ]
  },
  {
    id: "record2",
    patientId: "patient1",
    doctorId: "doctor2",
    doctorName: "Dr. Michael Chen",
    type: "lab-result",
    title: "Blood Work Results",
    description: "Complete blood count and metabolic panel. All results within normal ranges except for slightly elevated cholesterol.",
    date: "2025-02-28",
    attachments: [
      {
        name: "CBC_Results.pdf",
        url: "#",
        type: "application/pdf"
      }
    ]
  },
  {
    id: "record3",
    patientId: "patient1",
    doctorId: "doctor1",
    doctorName: "Dr. Sarah Johnson",
    type: "prescription",
    title: "Medication Prescription",
    description: "Prescription for blood pressure management and cholesterol control.",
    date: "2025-03-15",
    prescriptions: [
      {
        name: "Lisinopril",
        dosage: "10mg",
        frequency: "Once daily",
        duration: "3 months"
      },
      {
        name: "Atorvastatin",
        dosage: "20mg",
        frequency: "Once daily at bedtime",
        duration: "6 months"
      }
    ]
  },
  {
    id: "record4",
    patientId: "patient1",
    doctorId: "doctor3",
    doctorName: "Dr. James Wilson",
    type: "radiology",
    title: "Chest X-Ray",
    description: "Chest X-ray performed to rule out pneumonia. Results show clear lung fields with no abnormalities detected.",
    date: "2025-01-10",
    attachments: [
      {
        name: "Chest_XRay.jpg",
        url: "#",
        type: "image/jpeg"
      },
      {
        name: "Radiology_Report.pdf",
        url: "#",
        type: "application/pdf"
      }
    ]
  },
  {
    id: "record5",
    patientId: "patient1",
    doctorId: "doctor1",
    doctorName: "Dr. Sarah Johnson",
    type: "note",
    title: "Follow-up Visit Notes",
    description: "Patient reports improved symptoms. Blood pressure has decreased to 130/85 mmHg. Continue current treatment plan.",
    date: "2025-04-01"
  }
];

const RecordDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  
  if (!user) return null;
  
  const record = mockMedicalRecords.find(rec => rec.id === id);
  
  if (!record) {
    return (
      <div className="flex flex-col items-center justify-center py-12">
        <AlertCircle className="h-12 w-12 text-health-red mb-4" />
        <h1 className="text-2xl font-bold mb-2">Record Not Found</h1>
        <p className="text-gray-600 mb-4">The medical record you're looking for doesn't exist or has been removed.</p>
        <Button onClick={() => navigate("/medical-records")}>
          Go Back to Medical Records
        </Button>
      </div>
    );
  }
  
  // Format date
  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };
  
  // Get color based on record type
  const getTypeColor = () => {
    switch (record.type) {
      case "diagnosis":
        return "bg-health-blue-light text-health-blue";
      case "prescription":
        return "bg-health-green-light text-health-green";
      case "lab-result":
        return "bg-purple-100 text-purple-600";
      case "radiology":
        return "bg-amber-100 text-amber-600";
      case "note":
        return "bg-gray-100 text-gray-600";
      default:
        return "bg-gray-100 text-gray-600";
    }
  };
  
  return (
    <div className="animate-fade-in space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => navigate("/medical-records")}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-2xl font-bold">Medical Record Details</h1>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2 space-y-6">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                <CardTitle className="text-lg font-medium">{record.title}</CardTitle>
                <Badge variant="outline" className={`${getTypeColor()} border-0 whitespace-nowrap`}>
                  {record.type.charAt(0).toUpperCase() + record.type.slice(1).replace('-', ' ')}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <Calendar className="h-4 w-4 text-gray-500 mr-2" />
                  <span className="text-sm text-gray-500">{formatDate(record.date)}</span>
                </div>
                <div className="flex items-center">
                  <User className="h-4 w-4 text-gray-500 mr-2" />
                  <span className="text-sm text-gray-500">{record.doctorName}</span>
                </div>
              </div>
              
              <div className="pt-4 border-t border-gray-100">
                <h3 className="font-medium mb-2">Description</h3>
                <p className="text-gray-700">{record.description}</p>
              </div>
              
              {record.prescriptions && record.prescriptions.length > 0 && (
                <div className="pt-4 border-t border-gray-100">
                  <h3 className="font-medium mb-3">Prescriptions</h3>
                  <div className="space-y-3">
                    {record.prescriptions.map((prescription, index) => (
                      <div key={index} className="flex items-start bg-health-green-light/20 p-3 rounded-lg">
                        <Pill className="h-5 w-5 text-health-green mt-0.5 mr-3" />
                        <div>
                          <h4 className="font-medium text-gray-800">{prescription.name}</h4>
                          <p className="text-sm text-gray-600">
                            {prescription.dosage} - {prescription.frequency}
                          </p>
                          <p className="text-xs text-gray-500 mt-1">Duration: {prescription.duration}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              
              {record.attachments && record.attachments.length > 0 && (
                <div className="pt-4 border-t border-gray-100">
                  <h3 className="font-medium mb-3">Attachments</h3>
                  <div className="space-y-2">
                    {record.attachments.map((attachment, index) => (
                      <div key={index} className="flex items-center justify-between bg-gray-50 p-3 rounded-lg">
                        <div className="flex items-center">
                          <FileText className="h-5 w-5 text-gray-500 mr-3" />
                          <span>{attachment.name}</span>
                        </div>
                        <Button variant="ghost" size="sm">
                          <Download className="h-4 w-4 mr-1" />
                          Download
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
            <CardFooter className="border-t border-gray-100 pt-4 gap-2 flex flex-wrap">
              <Button variant="outline">
                <Printer className="h-4 w-4 mr-2" />
                Print Record
              </Button>
              <Button variant="outline">
                <Download className="h-4 w-4 mr-2" />
                Download PDF
              </Button>
            </CardFooter>
          </Card>
        </div>
        
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg font-medium">Related Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {record.type === "diagnosis" && (
              <div className="space-y-3">
                <h3 className="font-medium text-sm">Recommended Tests</h3>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <Microscope className="h-4 w-4 text-health-blue mr-2 mt-0.5" />
                    <span className="text-sm">Complete Blood Count</span>
                  </li>
                  <li className="flex items-start">
                    <Microscope className="h-4 w-4 text-health-blue mr-2 mt-0.5" />
                    <span className="text-sm">Lipid Panel</span>
                  </li>
                  <li className="flex items-start">
                    <Microscope className="h-4 w-4 text-health-blue mr-2 mt-0.5" />
                    <span className="text-sm">Kidney Function Test</span>
                  </li>
                </ul>
              </div>
            )}
            
            {record.type === "lab-result" && (
              <div className="space-y-3">
                <h3 className="font-medium text-sm">Related Diagnoses</h3>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <FileText className="h-4 w-4 text-health-blue mr-2 mt-0.5" />
                    <span className="text-sm">Hypertension Diagnosis (March 15, 2025)</span>
                  </li>
                </ul>
              </div>
            )}
            
            <div className="pt-4 border-t border-gray-100">
              <h3 className="font-medium text-sm mb-3">Patient Information</h3>
              <div className="text-sm">
                <p className="flex justify-between py-1 border-b border-gray-100">
                  <span className="text-gray-500">Name:</span>
                  <span className="font-medium">John Doe</span>
                </p>
                <p className="flex justify-between py-1 border-b border-gray-100">
                  <span className="text-gray-500">Age:</span>
                  <span className="font-medium">42</span>
                </p>
                <p className="flex justify-between py-1 border-b border-gray-100">
                  <span className="text-gray-500">Blood Type:</span>
                  <span className="font-medium">A+</span>
                </p>
                <p className="flex justify-between py-1 border-b border-gray-100">
                  <span className="text-gray-500">Allergies:</span>
                  <span className="font-medium">Penicillin</span>
                </p>
              </div>
            </div>
            
            <div className="flex flex-col gap-2 pt-4">
              <Button variant="default" className="w-full" onClick={() => navigate("/medical-records")}>
                <FileText className="h-4 w-4 mr-2" />
                View All Records
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default RecordDetails;
