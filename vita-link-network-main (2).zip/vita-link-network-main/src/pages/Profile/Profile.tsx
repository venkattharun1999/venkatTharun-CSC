
import React, { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardFooter 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  User, 
  Mail, 
  Phone, 
  Home, 
  Calendar, 
  Key, 
  Shield, 
  Droplet,
  Upload
} from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const Profile: React.FC = () => {
  const { user, updateUser } = useAuth();
  const { toast } = useToast();
  
  const [activeTab, setActiveTab] = useState("personal");
  const [isEditing, setIsEditing] = useState(false);
  const [isChangingPassword, setIsChangingPassword] = useState(false);
  
  // Form states
  const [formData, setFormData] = useState({
    name: user?.name || "",
    email: user?.email || "",
    phone: user?.phone || "",
    address: user?.address || "",
    dateOfBirth: user?.dateOfBirth || "",
    bloodType: user?.bloodType || "",
    specialization: user?.specialization || "",
    department: user?.department || "",
    medicalHistory: user?.medicalHistory || "",
    profilePicture: user?.profilePicture || ""
  });
  
  const [passwordData, setPasswordData] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: ""
  });
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  if (!user) return null;
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handlePasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setPasswordData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleSelectChange = (name: string, value: string) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      updateUser(formData);
      setIsEditing(false);
      setIsSubmitting(false);
    }, 1000);
  };
  
  const handlePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      toast({
        title: "Passwords do not match",
        description: "New password and confirmation password must match.",
        variant: "destructive",
      });
      return;
    }
    
    setIsSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      toast({
        title: "Password updated",
        description: "Your password has been successfully updated.",
      });
      setIsChangingPassword(false);
      setIsSubmitting(false);
      setPasswordData({
        currentPassword: "",
        newPassword: "",
        confirmPassword: ""
      });
    }, 1000);
  };
  
  const handleUploadClick = () => {
    // In a real app, this would open a file picker
    toast({
      title: "Feature not available",
      description: "File upload functionality is not available in this demo.",
    });
  };
  
  return (
    <div className="animate-fade-in space-y-6">
      <h1 className="text-2xl font-bold">My Profile</h1>
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid grid-cols-1 md:grid-cols-3 mb-6">
          <TabsTrigger value="personal">Personal Information</TabsTrigger>
          <TabsTrigger value="security">Security</TabsTrigger>
          {user.role === "patient" && (
            <TabsTrigger value="medical">Medical Information</TabsTrigger>
          )}
        </TabsList>
        
        <TabsContent value="personal">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="md:col-span-2">
              <CardHeader className="pb-3 flex flex-row items-center justify-between">
                <CardTitle className="text-lg font-medium">Personal Information</CardTitle>
                {!isEditing ? (
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={() => setIsEditing(true)}
                  >
                    Edit Profile
                  </Button>
                ) : (
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => setIsEditing(false)}
                  >
                    Cancel
                  </Button>
                )}
              </CardHeader>
              <form onSubmit={handleSubmit}>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Full Name</Label>
                      <div className="flex">
                        <div className="bg-gray-50 p-2 rounded-l-md border border-r-0 border-gray-200">
                          <User className="h-5 w-5 text-gray-500" />
                        </div>
                        <Input
                          id="name"
                          name="name"
                          value={formData.name}
                          onChange={handleInputChange}
                          disabled={!isEditing}
                          className="rounded-l-none"
                        />
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <div className="flex">
                        <div className="bg-gray-50 p-2 rounded-l-md border border-r-0 border-gray-200">
                          <Mail className="h-5 w-5 text-gray-500" />
                        </div>
                        <Input
                          id="email"
                          name="email"
                          type="email"
                          value={formData.email}
                          onChange={handleInputChange}
                          disabled={!isEditing}
                          className="rounded-l-none"
                        />
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone Number</Label>
                      <div className="flex">
                        <div className="bg-gray-50 p-2 rounded-l-md border border-r-0 border-gray-200">
                          <Phone className="h-5 w-5 text-gray-500" />
                        </div>
                        <Input
                          id="phone"
                          name="phone"
                          value={formData.phone || ""}
                          onChange={handleInputChange}
                          disabled={!isEditing}
                          className="rounded-l-none"
                        />
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="dateOfBirth">Date of Birth</Label>
                      <div className="flex">
                        <div className="bg-gray-50 p-2 rounded-l-md border border-r-0 border-gray-200">
                          <Calendar className="h-5 w-5 text-gray-500" />
                        </div>
                        <Input
                          id="dateOfBirth"
                          name="dateOfBirth"
                          type="date"
                          value={formData.dateOfBirth || ""}
                          onChange={handleInputChange}
                          disabled={!isEditing}
                          className="rounded-l-none"
                        />
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="address">Address</Label>
                    <div className="flex">
                      <div className="bg-gray-50 p-2 rounded-l-md border border-r-0 border-gray-200">
                        <Home className="h-5 w-5 text-gray-500" />
                      </div>
                      <Textarea
                        id="address"
                        name="address"
                        value={formData.address || ""}
                        onChange={handleInputChange}
                        disabled={!isEditing}
                        className="rounded-l-none min-h-[80px]"
                      />
                    </div>
                  </div>
                  
                  {user.role === "doctor" && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 border-t border-gray-100 pt-4">
                      <div className="space-y-2">
                        <Label htmlFor="specialization">Specialization</Label>
                        {isEditing ? (
                          <Select
                            value={formData.specialization || ""}
                            onValueChange={(value) => handleSelectChange("specialization", value)}
                          >
                            <SelectTrigger id="specialization">
                              <SelectValue placeholder="Select specialization" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="cardiology">Cardiology</SelectItem>
                              <SelectItem value="neurology">Neurology</SelectItem>
                              <SelectItem value="orthopedics">Orthopedics</SelectItem>
                              <SelectItem value="dermatology">Dermatology</SelectItem>
                              <SelectItem value="pediatrics">Pediatrics</SelectItem>
                            </SelectContent>
                          </Select>
                        ) : (
                          <Input
                            id="specialization"
                            value={formData.specialization || ""}
                            disabled
                          />
                        )}
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="department">Department</Label>
                        {isEditing ? (
                          <Select
                            value={formData.department || ""}
                            onValueChange={(value) => handleSelectChange("department", value)}
                          >
                            <SelectTrigger id="department">
                              <SelectValue placeholder="Select department" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="emergency">Emergency</SelectItem>
                              <SelectItem value="outpatient">Outpatient</SelectItem>
                              <SelectItem value="inpatient">Inpatient</SelectItem>
                              <SelectItem value="surgery">Surgery</SelectItem>
                              <SelectItem value="radiology">Radiology</SelectItem>
                            </SelectContent>
                          </Select>
                        ) : (
                          <Input
                            id="department"
                            value={formData.department || ""}
                            disabled
                          />
                        )}
                      </div>
                    </div>
                  )}
                </CardContent>
                
                {isEditing && (
                  <CardFooter className="border-t border-gray-100 pt-4">
                    <Button 
                      type="submit"
                      className="ml-auto"
                      disabled={isSubmitting}
                    >
                      {isSubmitting ? "Saving Changes..." : "Save Changes"}
                    </Button>
                  </CardFooter>
                )}
              </form>
            </Card>
            
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg font-medium">Profile Picture</CardTitle>
              </CardHeader>
              <CardContent className="flex flex-col items-center">
                <Avatar className="h-32 w-32 mb-4">
                  <AvatarImage src={user.profilePicture || "https://i.pravatar.cc/150?img=1"} />
                  <AvatarFallback className="text-2xl">
                    {user.name.split(" ").map(n => n[0]).join("")}
                  </AvatarFallback>
                </Avatar>
                <div className="flex flex-col items-center gap-2">
                  <p className="text-sm text-gray-500 text-center mb-2">
                    Upload a profile picture in JPG or PNG format (max 2MB).
                  </p>
                  <Button 
                    type="button" 
                    variant="outline"
                    onClick={handleUploadClick}
                    className="w-full"
                  >
                    <Upload className="h-4 w-4 mr-2" />
                    Upload Picture
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="security">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="md:col-span-2">
              <CardHeader className="pb-3 flex flex-row items-center justify-between">
                <CardTitle className="text-lg font-medium">Change Password</CardTitle>
                {!isChangingPassword ? (
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={() => setIsChangingPassword(true)}
                  >
                    Change Password
                  </Button>
                ) : (
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => setIsChangingPassword(false)}
                  >
                    Cancel
                  </Button>
                )}
              </CardHeader>
              {isChangingPassword ? (
                <form onSubmit={handlePasswordSubmit}>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="currentPassword">Current Password</Label>
                      <div className="flex">
                        <div className="bg-gray-50 p-2 rounded-l-md border border-r-0 border-gray-200">
                          <Key className="h-5 w-5 text-gray-500" />
                        </div>
                        <Input
                          id="currentPassword"
                          name="currentPassword"
                          type="password"
                          value={passwordData.currentPassword}
                          onChange={handlePasswordChange}
                          className="rounded-l-none"
                          required
                        />
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="newPassword">New Password</Label>
                      <div className="flex">
                        <div className="bg-gray-50 p-2 rounded-l-md border border-r-0 border-gray-200">
                          <Key className="h-5 w-5 text-gray-500" />
                        </div>
                        <Input
                          id="newPassword"
                          name="newPassword"
                          type="password"
                          value={passwordData.newPassword}
                          onChange={handlePasswordChange}
                          className="rounded-l-none"
                          required
                        />
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="confirmPassword">Confirm New Password</Label>
                      <div className="flex">
                        <div className="bg-gray-50 p-2 rounded-l-md border border-r-0 border-gray-200">
                          <Key className="h-5 w-5 text-gray-500" />
                        </div>
                        <Input
                          id="confirmPassword"
                          name="confirmPassword"
                          type="password"
                          value={passwordData.confirmPassword}
                          onChange={handlePasswordChange}
                          className="rounded-l-none"
                          required
                        />
                      </div>
                    </div>
                    
                    <p className="text-sm text-gray-500">
                      Password must be at least 8 characters long and include a mix of letters, numbers, and symbols.
                    </p>
                  </CardContent>
                  <CardFooter className="border-t border-gray-100 pt-4">
                    <Button 
                      type="submit"
                      className="ml-auto"
                      disabled={isSubmitting}
                    >
                      {isSubmitting ? "Updating Password..." : "Update Password"}
                    </Button>
                  </CardFooter>
                </form>
              ) : (
                <CardContent>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <div className="flex items-start">
                      <Shield className="h-5 w-5 text-gray-500 mt-0.5 mr-3" />
                      <div>
                        <h3 className="font-medium mb-1">Password & Security</h3>
                        <p className="text-sm text-gray-600">
                          Your password was last updated on {new Date(user.createdAt).toLocaleDateString()}.
                          It's recommended to change your password regularly to maintain account security.
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              )}
            </Card>
            
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg font-medium">Account Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <p className="text-sm text-gray-500">Role</p>
                  <div className="bg-gray-50 p-3 rounded-lg flex items-center">
                    <Shield className="h-5 w-5 text-health-blue mr-2" />
                    <span className="font-medium capitalize">{user.role}</span>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <p className="text-sm text-gray-500">Account Created</p>
                  <div className="bg-gray-50 p-3 rounded-lg flex items-center">
                    <Calendar className="h-5 w-5 text-health-blue mr-2" />
                    <span className="font-medium">
                      {new Date(user.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                </div>
                
                <div className="pt-4 border-t border-gray-100">
                  <Button 
                    variant="destructive" 
                    className="w-full"
                    onClick={() => {
                      toast({
                        title: "Feature not available",
                        description: "Account deletion is not available in this demo.",
                      });
                    }}
                  >
                    Delete Account
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        {user.role === "patient" && (
          <TabsContent value="medical">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="md:col-span-2">
                <CardHeader className="pb-3 flex flex-row items-center justify-between">
                  <CardTitle className="text-lg font-medium">Medical Information</CardTitle>
                  {!isEditing ? (
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={() => setIsEditing(true)}
                    >
                      Edit Information
                    </Button>
                  ) : (
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => setIsEditing(false)}
                    >
                      Cancel
                    </Button>
                  )}
                </CardHeader>
                <form onSubmit={handleSubmit}>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="bloodType">Blood Type</Label>
                        {isEditing ? (
                          <Select
                            value={formData.bloodType || ""}
                            onValueChange={(value) => handleSelectChange("bloodType", value)}
                          >
                            <SelectTrigger id="bloodType">
                              <SelectValue placeholder="Select blood type" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="A+">A+</SelectItem>
                              <SelectItem value="A-">A-</SelectItem>
                              <SelectItem value="B+">B+</SelectItem>
                              <SelectItem value="B-">B-</SelectItem>
                              <SelectItem value="AB+">AB+</SelectItem>
                              <SelectItem value="AB-">AB-</SelectItem>
                              <SelectItem value="O+">O+</SelectItem>
                              <SelectItem value="O-">O-</SelectItem>
                            </SelectContent>
                          </Select>
                        ) : (
                          <div className="flex">
                            <div className="bg-gray-50 p-2 rounded-l-md border border-r-0 border-gray-200">
                              <Droplet className="h-5 w-5 text-health-red" />
                            </div>
                            <Input
                              id="bloodType"
                              value={formData.bloodType || "Not specified"}
                              disabled
                              className="rounded-l-none"
                            />
                          </div>
                        )}
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="medicalHistory">Medical History</Label>
                      <Textarea
                        id="medicalHistory"
                        name="medicalHistory"
                        value={formData.medicalHistory || ""}
                        onChange={handleInputChange}
                        disabled={!isEditing}
                        className="min-h-[150px]"
                        placeholder="Include any allergies, chronic conditions, previous surgeries, or other relevant medical information."
                      />
                    </div>
                  </CardContent>
                  
                  {isEditing && (
                    <CardFooter className="border-t border-gray-100 pt-4">
                      <Button 
                        type="submit"
                        className="ml-auto"
                        disabled={isSubmitting}
                      >
                        {isSubmitting ? "Saving Changes..." : "Save Changes"}
                      </Button>
                    </CardFooter>
                  )}
                </form>
              </Card>
              
              <div className="space-y-6">
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg font-medium">Allergies & Medications</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <h3 className="font-medium text-sm mb-2">Known Allergies</h3>
                        <div className="p-3 bg-gray-50 rounded-lg">
                          <p className="text-sm text-gray-600">
                            {user.medicalHistory?.includes("allerg") 
                              ? "Penicillin, Peanuts" 
                              : "No known allergies recorded"}
                          </p>
                        </div>
                      </div>
                      
                      <div>
                        <h3 className="font-medium text-sm mb-2">Current Medications</h3>
                        <div className="p-3 bg-gray-50 rounded-lg">
                          <p className="text-sm text-gray-600">
                            {user.medicalHistory?.includes("hypertension") 
                              ? "Lisinopril 10mg (once daily), Atorvastatin 20mg (once daily at bedtime)" 
                              : "No current medications recorded"}
                          </p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg font-medium">Emergency Contact</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="p-3 bg-gray-50 rounded-lg">
                        <p className="font-medium">Jane Doe</p>
                        <p className="text-sm text-gray-600">Relationship: Spouse</p>
                        <p className="text-sm text-gray-600">Phone: (555) 123-4567</p>
                      </div>
                      <Button variant="outline" size="sm" className="w-full">
                        Update Emergency Contact
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>
        )}
      </Tabs>
    </div>
  );
};

export default Profile;
