
export type UserRole = 'patient' | 'doctor' | 'admin';

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  profilePicture?: string;
  specialization?: string; // For doctors
  department?: string; // For doctors
  medicalHistory?: string; // For patients
  phone?: string;
  address?: string;
  dateOfBirth?: string;
  bloodType?: string;
  createdAt: string;
}
