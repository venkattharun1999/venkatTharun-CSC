
export type RecordType = 'diagnosis' | 'prescription' | 'lab-result' | 'radiology' | 'note';

export interface MedicalRecord {
  id: string;
  patientId: string;
  doctorId: string;
  doctorName: string;
  type: RecordType;
  title: string;
  description: string;
  date: string;
  attachments?: {
    name: string;
    url: string;
    type: string;
  }[];
  prescriptions?: {
    name: string;
    dosage: string;
    frequency: string;
    duration: string;
  }[];
}
