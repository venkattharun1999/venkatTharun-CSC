
export type AppointmentStatus = 'pending' | 'confirmed' | 'cancelled' | 'completed';

export interface Appointment {
  id: string;
  patientId: string;
  patientName: string;
  patientAvatar?: string;
  doctorId: string;
  doctorName: string;
  doctorAvatar?: string;
  specialization: string;
  date: string;
  time: string;
  duration: number; // in minutes
  status: AppointmentStatus;
  symptoms?: string;
  notes?: string;
  createdAt: string;
}
